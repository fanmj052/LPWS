import copy
import os
import random

from joblib import Parallel, delayed

from tensorboard.compat.tensorflow_stub.io.gfile import exists
from os.path import exists
from os import mkdir

from Scheduler_Opt_Makespan.GRPHEFT import GRPHEFT
from Setting.Scheduler import Scheduler
from Setting.Solution import Solution
from Setting.VM import VM
from Setting.Workflow import Workflow
import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
import cma
import pandas as pd

tiny_num = 1E-8
class LPWS(Scheduler):

    # ----------------------------  训练样本设置  ----------------------------
    WorkflowFile = 'Workflow_data'
    SIZES = (50,)
    # SIZES = (100,)
    WORKFLOWS = ("CyberShake", "Epigenomics", "LIGO", "Montage", "Sipht")
    DF_START = 1
    DF_INCR = 1
    DF_END = 10
    # ----------------------------  训练设置  -----------------------------
    net_input_dim = 5  # 网络输入维度 None 5
    max_train_generation = 4000 #4000 10000
    hidden_node_num = 32 #隐藏层神经元个数,默认设置为 32
    is_parallel = True #是否使用并行 True or False
    parallel_jobs = 8 #并行CPU数目
    limit_gen_for_train = 10*SIZES[0] #训练时单个wf上的一次评价最大迭代次数
    # -------------------------------------------------------------------
    # ------------------------------- 策略设置 ----------------------------
    avg_speed_mode = "expect"  # fastest affordable expect
    is_permit_perturbation = True # 是否启用扰动,默认为True
    is_replace_perturbation_to_random = True  # 用于验证perturbation有效性,默认为 False
    is_replace_agent_to_random = False #用于验证agent有效性,默认为 False
    # -------------------------------------------------------------------
    is_finish_train = False  # 是否完成训练
    best_agent = None  # 训练得到的最优agent
    # -------------------------------------------------------------------

    def __init__(self):
        if LPWS.is_finish_train==False:
            self.train_net()

    def ini_best_agent(self): #初始化best_agent
        args = {
            'layer_dim': [self.net_input_dim, LPWS.hidden_node_num, LPWS.hidden_node_num, 1],
            'bias_bound': 1,
            'activate_function': 0
        }  # 网络结构参数
        LPWS.best_agent = Agent(args)
    def train_net(self): #训练网络
        path = os.path.join(os.path.pardir, "result", "planB_best_model")
        if os.path.exists(path):
            self.ini_best_agent()
            LPWS.best_agent.net.load_state_dict(torch.load(path))
        else:
            # 生成训练用的wf
            self.generate_train_workflows()
            # 生成训练wf对应的初始解
            self.generate_ini_solutions()
            # 确定网络输入向量维度
            TFs = LPWS.tasks_features(self.train_ini_sols[0])
            self.net_input_dim = TFs.shape[0]  # 输入向量维度
            # 创建多个智能体，每个智能体对应一个训练wf,方便并行评价在每一个wf上的表现
            args = {
                'layer_dim': [self.net_input_dim, LPWS.hidden_node_num, LPWS.hidden_node_num, 1],
                'bias_bound': 1,
                'activate_function': 0
            }  # 网络结构参数
            self.parallel_agents = [None] * len(self.train_ini_sols)
            for i in range(len(self.train_ini_sols)):
                agent = Agent(args)
                agent.id = i
                self.parallel_agents[i] = agent
            #训练
            #best_net_para = self.NaturalEvolutionStrategy(self.parallel_agents[0].x_dim)
            best_net_para = self.CMAES(self.parallel_agents[0].x_dim)
            # 提取最优模型
            self.ini_best_agent()
            LPWS.best_agent.set_params(best_net_para)
            torch.save(LPWS.best_agent.net.state_dict(), path)
            #结束
            LPWS.is_finish_train = True
            print('end train')

    def overall_evaluate_para(self,net_para): #评价一个网络参数的好坏
        self.eval_net_para = net_para #临时变量，存放要评价的网络参数
        if LPWS.is_parallel:
            result = Parallel(n_jobs=LPWS.parallel_jobs)(delayed(LPWS.evaluate_para_on_agent)(self.parallel_agents[i], self.train_ini_sols[i], self.eval_net_para) for i in range(len(self.parallel_agents)))
        else:
            result = []
            for i in range(len(self.parallel_agents)):
                res = LPWS.evaluate_para_on_agent(self.parallel_agents[i], self.train_ini_sols[i], self.eval_net_para)
                result.append(res)
        self.eval_net_para = None
        #print('end overall_evaluate_para')
        return sum(result) / len(result)  # 取平均

    def CMAES(self, dim):
        #创建写入路径
        path = os.path.join(os.path.pardir, "result", "figures")
        if not exists(path):
            mkdir(path)

        # ---------------开始CMAES---------------
        np.random.seed(2023) #固定种子,方便复现
        x0 = np.random.normal(0,0.1,dim)
        ec = cma.CMAEvolutionStrategy(x0,0.5,{'seed':2023})
        ec.optimize(self.overall_evaluate_para, maxfun =25 * LPWS.max_train_generation, iterations = None, verb_disp = True)
        # ----------------结束CMAES--------------

        print('best_fit =',ec.result[1])
        # 写入CMAES结果
        plt.figure(1)
        plt.plot(ec.log['best_fit'], color='b', linewidth=1)
        path = os.path.join(os.path.pardir, "result", "figures", "best_fit.jpg")
        plt.savefig(path)
        plt.close(1)

        plt.figure(1)
        plt.plot(ec.log['g_fit'], color='b', linewidth=1)
        path = os.path.join(os.path.pardir, "result", "figures", "g_fit.jpg")
        plt.savefig(path)
        plt.close(1)

        path = os.path.join(os.path.pardir, "result", "figures", "best_fit.csv")
        result = pd.DataFrame(ec.log['best_fit'])
        result.to_csv(path, header=None, index=False)

        path = os.path.join(os.path.pardir, "result", "figures", "g_fit.csv")
        result = pd.DataFrame(ec.log['g_fit'])
        result.to_csv(path, header=None, index=False)

        return ec.result[0]


    def evaluate_para_on_agent(agent,ini_sol,eval_net_para): #评价agent参数设置为self.eval_net_para后解makespan的变化
        # 设置网络参数
        agent.set_params(eval_net_para)
        # 获取agent对应wf以及初始解
        ini_fit = ini_sol.fitness_for_budget_constraints()
        # 生成新解
        S = LPWS.generate_sol_using_agent(ini_sol, agent)
        S_best_fit = S.fitness_for_budget_constraints()
        gen = ini_sol.used_FES + 1
        while(S.fitness_for_budget_constraints()<ini_sol.fitness_for_budget_constraints()-tiny_num):
            ini_sol = S
            S = LPWS.generate_sol_using_agent(ini_sol, agent)
            S_best_fit = min(S.fitness_for_budget_constraints(),S_best_fit)
            gen += 1
            if gen>=LPWS.limit_gen_for_train:
                break
        #self.update_best_solution(S)
        # 返回新旧makespan比例
        return S_best_fit / ini_fit

    def generate_sol_using_agent(ini_sol,agent): #提取ini_sol任务特征,输入agent得到新解
        TFs = LPWS.tasks_features(ini_sol)
        # 确定每一个任务的优先级
        task_priority_list = [None] * ini_sol.wf.task_num
        for t in range(ini_sol.wf.task_num):
            task_feature = TFs[:, t]
            p = agent.task_priority(task_feature)
            task_priority_list[t] = p
        S = Solution(ini_sol.wf)  # 初始化解
        sorted_task_list = S.sort_tasks_based_topo_and_key(task_priority_list)  # 任务排序
        S.build_HEFT(list(ini_sol.leased_VM_types), list(ini_sol.available_VM_hour), sorted_task_list)
        S.task_priority_list = task_priority_list #存储优先级,用于后续扰动
        return S

    def generate_train_workflows(self):
        self.train_wfs = []
        # ----------------------------  设置  ----------------------------
        WorkflowFile = LPWS.WorkflowFile
        SIZES = LPWS.SIZES
        WORKFLOWS = LPWS.WORKFLOWS
        DF_START = LPWS.DF_START
        DF_INCR = LPWS.DF_INCR
        DF_END = LPWS.DF_END
        # -------------------------------------------------------------------

        # ----------------------------  开始生成wf  ----------------------------
        budgetNum = (int)((DF_END - DF_START) / DF_INCR + 1 + tiny_num)  # 每个benchmark的budget约束个数
        for workflow in WORKFLOWS:  # 遍历每一个工作流
            # 遍历当前工作流类的每一个size
            for si in range(len(SIZES)):
                size = SIZES[si]  # 任务数
                wf_path = os.path.join(os.path.pardir, WorkflowFile, workflow + '_' + str(size) + '.txt')  # 工作流读取路径
                wf = Workflow(wf_path)  # 构建wf
                base_cost = wf.cheap_schedule_cost  # 获取budget下界
                # 遍历每一个budget
                for di in range(budgetNum):
                    budget = base_cost * (di + 1) + tiny_num  # budget约束值
                    wf.set_budget(budget)  #设置budget约束值
                    wf_copy = copy.deepcopy(wf)  # 深拷贝
                    self.train_wfs.append(wf_copy)
        print('end generate_train_workflows')

    def generate_ini_solutions(self): #生成用于训练的初始解
        if LPWS.is_parallel:
            self.train_ini_sols = Parallel(n_jobs=LPWS.parallel_jobs)(
                delayed(LPWS.ini_func)(wf) for wf in self.train_wfs)
        else:
            self.train_ini_sols = []
            for wf in self.train_wfs:
                self.train_ini_sols.append(LPWS.ini_func(wf))
        print('end generate_ini_solutions')


    def ini_func(wf): #初始化wf对应的解
        scheduler = GRPHEFT()
        ini_sol = scheduler.schedule(wf)
        ini_sol.used_FES = scheduler.fes
        return ini_sol

    def predict_avg_speed(ini_sol):
        avg_speed = VM.SPEEDS[VM.FASTEST]
        if LPWS.avg_speed_mode == "fastest":  # 用最快机器
            avg_speed = VM.SPEEDS[VM.FASTEST]
        elif LPWS.avg_speed_mode == "affordable":  # 用费用不超过budget的最快机器
            avg_speed = 0.0
            budget = ini_sol.wf.budget
            for ty in ini_sol.leased_VM_types:  # range(len(self.leased_VM_types-1),-1,-1)
                if VM.UNIT_COSTS[ty] <= budget + tiny_num:
                    avg_speed = max(avg_speed,VM.SPEEDS[ty])
        elif LPWS.avg_speed_mode == "expect":  # 用速度超过ex_speed的最便宜机器
            sum_n = 0.0
            sum_speed = 0.0
            for i in range(len(ini_sol.leased_VM_types)):
                ty = ini_sol.leased_VM_types[i]
                n = ini_sol.available_VM_hour[ty]
                sum_n += n
                sum_speed += VM.SPEEDS[ty] * n
            avg_speed = sum_speed / sum_n
        else:
            print("avg_speed_mode ERROR")
            while True:
                pass
        return avg_speed

    def tasks_features(sol): #获取sol对应的任务特征

        # 生成任务特征
        avg_speed = LPWS.predict_avg_speed(sol)
        #   D0特征
        D0 = sol.wf.get_D0(avg_speed)  # 每个任务开始到exit_task的预估关键路径长度,不忽略边传输时间
        fD0 = np.array(D0[0])/D0[0][sol.wf.entry_task]
        #   Dn特征
        Dn = sol.wf.get_Dn(avg_speed)  # 每个任务开始到exit_task的预估关键路径长度，忽略边传输时间
        fDn = np.array(Dn[0]) / Dn[0][sol.wf.entry_task]
        #   D特征
        D = sol.get_D()  # 每个任务开始到exit_task的实际关键路径长度
        fD = np.array(D[0]) / D[0][sol.wf.entry_task]
        #   T特征(经testD验证无效)
        T = sol.get_T()  # 每个任务开始到exit_task的实际时间差
        fT = np.array(T[0]) / sol.makespan
        #   F特征
        F = sol.get_flex_time()  # Flex time,表示每个任务推测多久开始仍然可满足deadline约束
        fF = np.array(F) / sol.makespan

        #生成特征矩阵testD
        TFs = np.row_stack((fD0,fDn,fD,fT,fF)) #配置D0,全特征
        #TFs = np.row_stack((fDn,fD,fT,fF))  # 配置D1,去掉D0
        #TFs = np.row_stack((fD0, fD, fT, fF))  # 配置D2,去掉Dn
        #TFs = np.row_stack((fD0, fDn, fT, fF))  # 配置D3,去掉fD
        #TFs = np.row_stack((fD0, fDn, fD, fF))  # 配置D4,去掉fT
        #TFs = np.row_stack((fD0, fDn, fD, fT))  # 配置D5,去掉F
        #TFs = np.row_stack((fD0,fD,fT,fF))
        #TFs = np.row_stack((fD, fT, fF))


        '''
        #生成特征矩阵testE
        TFs = np.row_stack((fD0, fDn, fD, fF))  # 配置E0,去掉fT
        #TFs = np.row_stack((fDn, fD, fF))  # 配置E1,无特征D0
        #TFs = np.row_stack((fD0, fD, fF))  # 配置E2,无特征fDn
        #TFs = np.row_stack((fD0, fDn, fF))  # 配置E3,无特征fD
        #TFs = np.row_stack((fD0, fDn, fD))  # 配置E4,去掉fF
        '''

        return TFs

    def is_better(self,sol1,sol2): #解1是否比解2好
        return sol1.fitness_for_budget_constraints() < sol2.fitness_for_budget_constraints() - tiny_num
    def best_one(self,old_sol,new_sol): #比较两个解，如果new_sol优于old_sol则返回new_sol，否则返回old_sol
        is_update = self.is_better(new_sol,old_sol)
        if is_update:
            return new_sol
        else:
            return old_sol

    def normalize_task_priority(self,task_priority_list):
        ub = max(task_priority_list)
        lb = min(task_priority_list)
        L = ub - lb
        for i in range(len(task_priority_list)):
            task_priority_list[i] = (task_priority_list[i]-lb) / L
        return task_priority_list

    def random_priority_list(task_num):
        pl = [0.0] * task_num
        for i in range(task_num):
            pl[i] = random.random()
        return pl


    def schedule(self, wf):  # 调度
        # 策略配置
        is_permit_perturbation = LPWS.is_permit_perturbation
        is_replace_agent_to_random = LPWS.is_replace_agent_to_random
        # 初始化
        max_FES = wf.task_num * 10 #最大迭代次数
        agent = LPWS.best_agent #训练得到的agent
        ini_sol = LPWS.ini_func(wf)#初始解
        best_sol = ini_sol #初始化最优解
        FES = ini_sol.used_FES
        # 生成第一个新解
        S = None
        if is_replace_agent_to_random == True:
            pl = LPWS.random_priority_list(wf.task_num)
            S = Solution(wf)  # 初始化解
            sorted_task_list = S.sort_tasks_based_topo_and_key(pl)  # 任务排序
            S.build_HEFT(list(ini_sol.leased_VM_types), list(ini_sol.available_VM_hour), sorted_task_list)
            S.task_priority_list = pl  # 存储优先级,用于后续扰动
        else:
            S = LPWS.generate_sol_using_agent(ini_sol, agent)

        perturb_sol = S #执行扰动操作的解
        best_sol = self.best_one(best_sol, S)
        old_S = None
        # 迭代

        while (FES <= max_FES):
            #print("FES =",FES)
            #更新perturb_sol,best_sol
            perturb_sol = self.best_one(perturb_sol,S)
            best_sol = self.best_one(best_sol,S)
            # 决策是否扰动
            is_perturb = True
            if old_S == None or self.is_better(S,old_S): #得到比上一个解更好的解
                is_perturb = False
            old_S = S
            #生成新解
            if is_perturb==False: #无需扰动，使用上一个解继续生成新解
                S = None
                if is_replace_agent_to_random == True:
                    pl = LPWS.random_priority_list(wf.task_num)
                    S = Solution(wf)  # 初始化解
                    sorted_task_list = S.sort_tasks_based_topo_and_key(pl)  # 任务排序
                    S.build_HEFT(list(ini_sol.leased_VM_types), list(ini_sol.available_VM_hour), sorted_task_list)
                    S.task_priority_list = pl  # 存储优先级,用于后续扰动
                else:
                    S = LPWS.generate_sol_using_agent(old_S, agent)
                #print("    new sol using_agent")
            else: #扰动，扰动perturb_sol的优先级,生成新解
                if is_permit_perturbation == False: #不允许扰动则直接停止迭代
                    break
                #执行扰动
                if LPWS.is_replace_perturbation_to_random: #全随机优先级
                    pl = LPWS.random_priority_list(wf.task_num)
                else: #扰动的优先级
                    pl = self.normalize_task_priority(list(perturb_sol.task_priority_list))
                    perturb_range = 0.5*(max_FES - FES)/max_FES #扰动幅度
                    #扰动任务优先级向量pl
                    for i in range(len(pl)):
                        pl[i] += random.uniform(-perturb_range, perturb_range)
                #使用扰动后的pl生成新的解
                S = Solution(wf)  # 初始化解
                sorted_task_list = S.sort_tasks_based_topo_and_key(pl)  # 任务排序
                S.build_HEFT(list(ini_sol.leased_VM_types), list(ini_sol.available_VM_hour), sorted_task_list)
                S.task_priority_list = pl  # 存储优先级,用于后续扰动
                old_S = None
                #print("    new sol using_perturb")
            FES += 1
        return best_sol

    def schedule_test(self, wf):  #PlanB排除初始化解,得到的最优解
        ini_sol = LPWS.ini_func(wf)
        FES = ini_sol.used_FES
        max_FES = wf.task_num * 100
        agent = LPWS.best_agent
        S = LPWS.generate_sol_using_agent(ini_sol, agent)
        FES += 1
        best_sol = None #与schedule不同的一行
        while (best_sol == None or S.fitness_for_budget_constraints() < best_sol.fitness_for_budget_constraints() - tiny_num):
            best_sol = S
            S = LPWS.generate_sol_using_agent(best_sol, agent)
            FES += 1
            if FES>max_FES:
                break
        return best_sol

class Net(nn.Module):
    def __init__(self, args): #input_dim为输入网络的入口,weight为网络权重
        super(Net, self).__init__()
        self.layers = len(args['layer_dim'])-1 #args.layer_dim = [输入层，隐藏层1，隐藏层2，输出层] 经过3层计算
        #self.fcs = [nn.Linear(args['layer_dim'][i], args['layer_dim'][i+1]) for i in range(self.layers)]
        self.fc1 = nn.Linear(args['layer_dim'][0],args['layer_dim'][1])
        self.fc2 = nn.Linear(args['layer_dim'][1],args['layer_dim'][2])
        self.fc3 = nn.Linear(args['layer_dim'][2],args['layer_dim'][3])

        self.activate_function = [
            nn.PReLU(),
            nn.Sigmoid(),
            nn.Tanh(),
            nn.Softmax(),
            nn.Softplus(),
            nn.ReLU(),

        ][args['activate_function']]

        #for i in range(self.layers):
        #    nn.init.orthogonal_(self.fcs[i].weight, gain=1)
        #    nn.init.constant_(self.fcs[i].bias, 0)

    def forward(self, x):
        #for i in range(self.layers):
        #    x = self.activate_function(self.fcs[i](x))
        x = self.activate_function(self.fc1(x))
        x = self.activate_function(self.fc2(x))
        x = self.activate_function(self.fc3(x))
        return x

class Agent:
    id = None #并行处理使用
    def __init__(self, args):
        self.net = Net(args)
        self.para_dim = []
        self.layer_dim = args['layer_dim']
        self.bias_bound = args['bias_bound']
        for i in range(len(args['layer_dim'])-1):
            self.para_dim.append(args['layer_dim'][i]*args['layer_dim'][i+1])
        self.weight_dim = np.sum(self.para_dim) #weight参数总量
        for i in range(len(args['layer_dim']) - 1):
            self.para_dim.append(args['layer_dim'][i+1])
        self.slice = np.cumsum([0]+self.para_dim) #每层weight bias对应下标
        self.x_dim = np.sum(self.para_dim) #参数总量


    def task_priority(self, task_feature):
        x = torch.unsqueeze(torch.tensor(task_feature, dtype=torch.float), 0)
        with torch.no_grad():
            priority = self.net(x)
        return priority.item()

    def set_params(self, para): #para类型numpy
        para = np.array(para,dtype=np.float32)
        weights = []
        for i in range(len(self.layer_dim)-1):
            weight = para[self.slice[i]:self.slice[i+1]]
            weight.resize((self.layer_dim[i+1],self.layer_dim[i]))
            weights.append(weight)
        biases = []
        for i in range(len(self.layer_dim)-1,len(self.slice)-1):
            bias = para[self.slice[i]:self.slice[i+1]] * self.bias_bound
            biases.append(bias)
        self.net.fc1.weight = torch.nn.Parameter(torch.tensor(weights[0]).requires_grad_())
        self.net.fc2.weight = torch.nn.Parameter(torch.tensor(weights[1]).requires_grad_())
        self.net.fc3.weight = torch.nn.Parameter(torch.tensor(weights[2]).requires_grad_())
        self.net.fc1.bias = torch.nn.Parameter(torch.tensor(biases[0]).requires_grad_())
        self.net.fc2.bias = torch.nn.Parameter(torch.tensor(biases[1]).requires_grad_())
        self.net.fc3.bias = torch.nn.Parameter(torch.tensor(biases[2]).requires_grad_())


class PlanB_test(Scheduler): #PlanB不包括初始化解得到的最优解
    def __init__(self):
        self.PB = LPWS()

    def schedule(self, wf):
        return self.PB.schedule_test(wf)


if __name__ == '__main__':
    args = {
        'layer_dim' : [4,2,2,1],
        'bias_bound' : 1,
        'activate_function' : 0
    }
    agent = Agent(args)
    priority = agent.task_priority(np.array([0,0,0,0])) #输出一个任务优先级
    print(priority)
    print(list(agent.net.parameters()))  # 查看网络参数

    agent.set_params(np.array(range(19),dtype=np.float32)/19) #设置网络参数
    print(list(agent.net.parameters())) #查看网络参数
    priority = agent.task_priority(np.array([0,0,0,0])) #输出一个任务优先级
    print(priority)