from functools import cmp_to_key

from Setting.Scheduler import Scheduler
from Setting.Solution import Solution
from Setting.VM import VM


class GRPHEFT(Scheduler):
    leased_VM_types = [] #租用机器的全部类型,按照性价比从前往后排序
    available_VM_hour = [] #各个租用机器类型的个数(每个机器租用1个计费时段)
    avg_speed = 0.0 #所有租赁机器的平均处理速度
    best_solution = None #发现的最优解
    fes = 0 #使用的评价次数
    is_print_information = False # 是否打印过程信息 True or False

    def __init__(self):
        super().__init__()

    def schedule(self,wf): #调度
        self.wf = wf
        self.fes = 0
        #print('budget = ', self.wf.budget)
        #候选机器类型
        rtl0 = VM.non_dominated_types() #获取所有非支配机器类型
        rtl0.sort(key=cmp_to_key(VM.cmp_based_EffRate)) #根据EffRate对机器类型排序,高EffRate排在前,同EffRate则高speed排在前
        rtl = [] #单位时段租金低于的budget机器类型
        for y in rtl0:
            if VM.UNIT_COSTS[y]<self.wf.budget+self.tiny_num:
                rtl.append(y)
        #生成调度解
        while len(rtl)>0:
            self.lease_VM(rtl) #贪心租用rtl最靠前的机器类型
            D0_sf = self.wf.get_D0(self.avg_speed) #计算任务优先级
            D0 = D0_sf[0]
            S = Solution(wf) #初始化解
            sorted_task_list = S.sort_tasks_based_topo_and_key(D0) #任务排序
            S.build_HEFT(self.leased_VM_types,self.available_VM_hour,sorted_task_list)
            self.update_best_solution(S)
            self.fes += 1

            del rtl[0]
        if self.is_print_information:
            print('GRPHEFT: end scheduling')
        return self.best_solution

    def update_best_solution(self,new_solution): #更新最优解
        is_update = False
        #对比self.best_solution和new_solution，new_solution更好则设置is_update = True
        if self.best_solution==None: #最优解尚未初始化
            is_update = True
        else:
            bs_cost = self.best_solution.cost #最优解cost
            ns_cost = new_solution.cost #新解cost
            bs_makespan = self.best_solution.makespan #最优解makespan
            ns_makespan = new_solution.makespan #新解makespan
            bs_feasiblity = bs_cost < self.wf.budget + self.tiny_num #最优解feasiblity
            ns_feasiblity = ns_cost < self.wf.budget + self.tiny_num #新解feasiblity
            if ns_feasiblity==True: #新解可行
                if bs_feasiblity==False or bs_makespan>ns_makespan+self.tiny_num: #最优解不可行或者其makespan更高
                    is_update = True
            else: #新解不可行
                if bs_feasiblity == False and bs_cost>ns_cost+self.tiny_num: ##最优解不可行 且 其cost更高
                    is_update = True
        #更新self.best_solution
        if is_update:
            self.best_solution = new_solution
            if self.is_print_information:
                print('update best solution')





    def lease_VM(self,rtl): #贪心租用rtl最靠前的机器类型
        #清空租用机器类型及其数量
        self.leased_VM_types = []  # 租用机器的全部类型,按照性价比从前往后排序
        self.available_VM_hour = [0 for i in range(len(VM.UNIT_COSTS))]  # 各个租用机器类型的个数(每个机器租用1个计费时段)
        sum_n = 0.0
        sum_speed = 0.0
        #遍历rtl,确定租用机器类型及其时段数
        rb = self.wf.budget+self.tiny_num #剩余预算资金
        for y in rtl:
            uc = VM.UNIT_COSTS[y]
            n = int(rb/uc)
            if n>0:
                self.leased_VM_types.append(y)
                self.available_VM_hour[y] = n
                rb = rb - uc*n
                sum_n = sum_n + n
                sum_speed = sum_speed + VM.SPEEDS[y]*n
        #计算平均处理速度
        self.avg_speed = sum_speed / sum_n
