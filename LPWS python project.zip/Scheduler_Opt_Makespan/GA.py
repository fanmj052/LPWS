import functools
import random
import matplotlib.pyplot as plt
import numpy as np
from functools import cmp_to_key

from Scheduler_Opt_Makespan.GRPHEFT import GRPHEFT
from Setting.Scheduler import Scheduler
import copy  # 用于深拷贝wf

from Setting.Solution import Solution
from Setting.VM import VM
from joblib import Parallel, delayed #支持并行

# GA求解cost约束makespan最小化调度问题,适应度评价函数基于AILS, 算法框架基于KAMSA(去除多目标部分)
# AILS: Qin S, Pi D, Shao Z. AILS: A budget-constrained adaptive iterated local search for workflow scheduling in cloud environment[J]. Expert Systems with Applications, 2022, 198: 116824.
# KAMSA：Knowledge-driven adaptive evolutionary multi-objective scheduling algorithm for cloud workflows
# 复现人: Fan,20250423
class GA(Scheduler):
    best_solution = None  # 发现的最优解
    G = None  # 决策变量分类结果
    max_fes = -1  # 最大迭代次数
    fes = 0  # 使用的评价次数
    is_print_information = False  # 是否打印过程信息 True or False
    # 参数
    pop_size = 200  # 种群规模 200
    pc = 1.0  # 交叉概率
    L = 12
    delta = 1e-6 # threshold
    pm = None # 变异概率, 实时更新为1/n'

    def __init__(self):
        super().__init__()


    def get_fes(self):
        return self.fes

    def schedule(self, wf):  # 调度
        self.wf = wf
        self.fes = 0
        self.G = []
        self.C = []
        self.max_fes = 100 * wf.task_num
        pl = self.random_priority_list()
        S = Solution(self.wf)
        self.sorted_task_list = S.sort_tasks_based_topo_and_key(pl)  # 计算拓扑排序

        # 生成候选机器集合

        rtl0 = VM.non_dominated_types()  # 获取所有非支配机器类型
        rtl0.sort(key=cmp_to_key(VM.cmp_based_EffRate))  # 根据EffRate对机器类型排序,高EffRate排在前,同EffRate则高speed排在前
        rtl = []  # 单位时段租金低于的budget机器类型
        for y in rtl0:
            if VM.UNIT_COSTS[y] < self.wf.budget + self.tiny_num:
                rtl.append(y)

        self.size_resource_pool = 0
        self.resource_index = []
        self.resource_type = []
        rb = self.wf.budget + self.tiny_num  # 预算资金
        for y in rtl0:
            uc = VM.UNIT_COSTS[y]
            n = int(rb / uc)
            if n>0:
                for i in range(n):
                    self.resource_index.append(self.size_resource_pool)
                    self.size_resource_pool = self.size_resource_pool + 1
                    self.resource_type.append(y)
                rb = rb - uc * n
        # 初始化种群
        pop = self.PopInitialization()  # 初始化种群
        self.group_decision_variables()
        # 迭代
        print('开始迭代')
        while self.fes <= self.max_fes:
            #s = self.cal_selection_probability(C)
            print('  生成子代...')
            index = len(self.G)-1 #允许全部任务变异
            self.pm = 1.0 / len(self.G[index]) #变异概率
            children = self.generate_children(pop, index)
            p_ = pop + children
            # 环境选择
            print('  环境选择...')
            p_ = sorted(p_, key=functools.cmp_to_key(self.compare_based_fit))   # 种群排序
            new_pop = list([p_[i] for i in range(0, self.pop_size)])
            pop = list(new_pop)
            self.update_best_solution(pop[0].sol)
            print('  完成一次迭代,fes =',self.fes)
        # 终止
        return self.best_solution

    def update_best_solution(self,new_solution): #更新最优解
        is_update = False
        #对比self.best_solution和new_solution，new_solution更好则设置is_update = True
        if self.best_solution==None: #最优解尚未初始化
            is_update = True
        else:
            bs_cost = self.best_solution.cost #最优解cost
            ns_cost = new_solution.cost #新解cost
            bs_makespan = self.best_solution.makespan #最优解makespan
            ns_makespan = new_solution.makespan #新解makespan
            bs_feasiblity = bs_cost < self.wf.budget + self.tiny_num #最优解feasiblity
            ns_feasiblity = ns_cost < self.wf.budget + self.tiny_num #新解feasiblity
            if ns_feasiblity==True: #新解可行
                if bs_feasiblity==False or bs_makespan>ns_makespan+self.tiny_num: #最优解不可行或者其makespan更高
                    is_update = True
            else: #新解不可行
                if bs_feasiblity == False and bs_cost>ns_cost+self.tiny_num: ##最优解不可行 且 其cost更高
                    is_update = True
        #更新self.best_solution
        if is_update:
            self.best_solution = new_solution
            #print(self.best_solution.makespan,self.best_solution.cost,self.wf.budget)
            if self.is_print_information:
                print('update best solution')

    def group_decision_variables(self):  # 变量分组
        G = self.G
        G.append([self.wf.task_num - 1])
        temp_count = 0
        G_l = []
        m = [0] * self.wf.task_num
        while np.sum(m) < self.wf.task_num:
            for i in range(0, self.wf.task_num):
                if i == self.wf.task_num - 1:
                    m[i] = 1
                if i < self.wf.task_num - 1:
                    if m[i] == 1:
                        continue
                    Flag = 1
                    for ct in self.wf.children[i]:
                        if m[ct] == 0:
                            Flag = 0
                    if Flag == 1:
                        G_l.append(i)
                else:
                    for j in G_l:
                        m[j] = 1
            if temp_count != 0:
                G.append(G_l)
            temp_count = temp_count + 1
            G_l = []
        for k in range(1, len(G)):
            G[k] = G[k] + G[k - 1]
        self.G = G

    def generate_children(self, pop, index):
        G = self.G
        new_pop = []
        child_num = 0
        children = []
        temp = []
        print('     交叉...')
        while child_num < self.pop_size:
            p1 = min(random.randint(0, len(pop) - 1), random.randint(0, len(pop) - 1))  # 父代1编号
            if random.random() < self.pc:  # 以概率pc执行交叉
                p2 = min(random.randint(0, len(pop) - 1), random.randint(0, len(pop) - 1))  # 父代2编号
                while p1 == p2:
                    p2 = min(random.randint(0, len(pop) - 1), random.randint(0, len(pop) - 1))  # 父代2编号
                c1, c2 = self.crossover(pop[p1], pop[p2], index)  # 执行交叉
                children.append(c1)  # 子代1
                children.append(c2)  # 子代2
            #else:  # 以概率1-pc直接使用父代1的基因
            #    C = Genome(self.wf)
                #C.task_mapped_VM = pop[p1].task_mapped_VM
            #    C.task_mapped_VM = list(pop[p1].task_mapped_VM)
            #    children.append(C)
            child_num = len(children)
        print('     变异...')
        for i in range(0, child_num):
            #if random.random() < self.pm:
            children[i].task_mapped_VM = self.mutation(children[i].task_mapped_VM, index)
        for i in range(0, child_num):
            new_pop.append(children[i])
            self.fes += 1  # 更新评价次数
        print('     解码...')
        #评价次数
        for i in range(len(new_pop)):
            print('          child ',i,' 解码...')
            child = Genome(self.wf)
            child.task_mapped_VM = new_pop[i].task_mapped_VM
            child.decode(child.task_mapped_VM, self.resource_type) #解码，评价解
            temp.append(child)
        return temp

    def crossover(self, pop1, pop2, index):

        C1 = Genome(self.wf)  # 子代1
        #C1.task_mapped_VM = list(pop2.task_mapped_VM)
        C2 = Genome(self.wf)  # 子代2
        #C2.task_mapped_VM = list(pop1.task_mapped_VM)
        C1.task_mapped_VM = self.cross_task_mapped_VM(pop1.task_mapped_VM, pop2.task_mapped_VM, index)
        C2.task_mapped_VM = self.cross_task_mapped_VM(pop2.task_mapped_VM, pop1.task_mapped_VM, index)
        return C1, C2

    def cross_task_mapped_VM(self, x, y, index):
        #S = []
        S = [0]*len(y)
        G_temp = self.G
        select = G_temp[index]
        length_select = len(select)
        p = random.randint(1, length_select)
        is_add = [True] * len(x)
        for i in select:
            is_add[i] = False
        for i in range(p):
            t = select[i]
            is_add[t] = True
        for i in range(len(y)):
            t = x[i]
            if not is_add[i]:
                t = y[i]
                is_add[i] = True
            #S.append(t)
            S[i] = t
        return S

    def compare_based_fit(self, ind1, ind2):  # 按照适应度值排序
        if ind1.get_fit() > ind2.get_fit():
            return 1
        else:
            return -1

    def mutation(self, x, index):
        G = self.G
        G_select = G[index]
        length_select = len(G_select)
        for i in range(length_select):
            if random.random() < self.pm:
                x[G_select[i]] = random.choice(self.resource_index)
        return x

    def PopInitialization(self):
        population = []
        for i in range(self.pop_size):
            rand_P = Genome(self.wf)
            rand_P.task_mapped_VM = []
            for j in range(self.wf.task_num):
                rand_P.task_mapped_VM.append(random.choice(self.resource_index))
            rand_P.decode(rand_P.task_mapped_VM,self.resource_type)
            population.append(rand_P)
            self.fes += 1
        return population

    def random_priority_list(self):
        pass
        pl = [0.0] * self.wf.task_num
        for i in range(self.wf.task_num):
            pl[i] = random.random()
        return pl

class Genome: #基因类，用于表示一个调度解
    # 基本信息
    task_mapped_VM = None #length=任务个数
    sol = None  # 解码生成的完整调度解
    # 适应度值(AILS)
    fitness = None

    def __init__(self, wf):
        self.sol = Solution(wf)
        self.wf = wf

    def copy_genome(self): #深拷贝一个Genome副本(sol没有复制,太耗时)
        new_g = Genome(self.wf)
        new_g.task_mapped_VM = list(self.task_mapped_VM)
        new_g.sol = None
        new_g.rank = None
        new_g.crowding_distance = None
        return new_g

    def decode(self, task_mapped_VM, VMs_type):  # 解码: task allocation,评价解
        # 确定每个任务的处理速度
        tasks_process_speed = [1.0] * len(task_mapped_VM)
        for i in range(len(task_mapped_VM)): #遍历每一个任务i
            vm_id = task_mapped_VM[i] #第i个任务使用的机器
            vm_type = VMs_type[vm_id] #机器类型
            speed = VM.SPEEDS[vm_type] #该类型的速度
            tasks_process_speed[i] = speed #记录任务i的处理速度
        # 确定任务处理顺序
        D0_sf = self.sol.wf.get_D0_with_diff_speed(tasks_process_speed)  # 计算任务优先级
        D0 = D0_sf[0]
        sorted_task_list = self.sol.sort_tasks_based_topo_and_key(D0)  # 任务排序
        # build完整的调度解
        self.sol.build_based_assigned_VM(sorted_task_list, task_mapped_VM, VMs_type)
        # 计算适应度值
        self.fitness = self.sol.fitness_for_budget_constraints()

    def get_cost(self):  # 获取解的cost
        return self.sol.cost

    def get_makespan(self):  # 获取解的完工时间
        return self.sol.makespan

    def get_fit(self):  # 获取解在非支配排序中的适应度值
        return self.fitness

    ##x 机器类型【i】 = 机器编号 length=机器个数
