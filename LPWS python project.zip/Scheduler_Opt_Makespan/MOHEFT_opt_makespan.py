import math

from Setting.Scheduler import Scheduler
from Setting.Solution import Solution
from Setting.VM import VM
import copy
import numpy as np
import functools
import matplotlib.pyplot as plt
from functools import cmp_to_key

# 修改MOHEFT算法，优化预算约束下的工作流完工时间优化问题
# 修改方案:遵循AILS算法实验部分,候选机器按照GRP-HEFT确定,中间调度解筛选时保留完工时间最小的K个解。（额外按照FDHEFT去除重复解）
# 复现人: fan
class MOHEFT_opt_makespan(Scheduler):
    wf = None  # 工作流
    useVMs = None  # 全部候选机器:Set of resources
    is_print_information = False  # 是否打印过程信息 True or False

    sorted_task_list = None  # 任务处理顺序
    best_solution = None  # 发现的最优解
    K = 10  # 参数:Number of tradeoff solutions

    def __init__(self):
        super().__init__()

    def schedule(self, wf):  # 调度
        #  ----------------------  初始化  ----------------------
        # 记录工作流
        self.wf = wf
        # 初始化任务处理顺序
        self.avg_speed = VM.avg_speed()  # 计算各机器类型平均处理速度
        D0_sf = self.wf.get_D0(self.avg_speed)  # 任务起始B-rank
        upward_rank = D0_sf[0]  # 取任务开始对应的rank
        S = Solution(self.wf)
        self.sorted_task_list = S.sort_tasks_based_topo_and_key(upward_rank)  # 计算拓扑排序
        #   开机器
        UseVMs = []
        rtl0 = VM.non_dominated_types()  # 获取所有非支配机器类型
        rtl0.sort(key=cmp_to_key(VM.cmp_based_EffRate))  # 根据EffRate对机器类型排序,高EffRate排在前,同EffRate则高speed排在前
        rb = self.wf.budget + self.tiny_num  # 预算资金
        for y in rtl0:
            uc = VM.UNIT_COSTS[y]
            n = int(rb / uc)
            if n > 0:
                for i in range(n):
                    vm = VM(y)
                    UseVMs.append(vm)
                rb = rb - uc * n
        self.useVMs = tuple(UseVMs)
        # 初始化种群
        S.clear_solution()
        S.UseVMs = self.useVMs
        S.set_entry_task_assignment()
        ind = partial_genome(wf)
        ind.sol = S
        POP = [ind, ]  # 父代种群,初始化为空解
        #  ---------------------- 结束初始化 -----------------------

        # ------------------------  迭代  -------------------------
        finish_task_num = 0  # 完成任务数
        while finish_task_num < len(self.sorted_task_list):  # 遍历每一个任务
            task = self.sorted_task_list[finish_task_num]  # 当前要处理的任务
            if task != self.wf.entry_task and task != self.wf.exit_task:  # 是真实任务则处理
                # 遍历所有task匹配机器的可能, 把所有分配方案存储在new_POP中
                new_POP = []
                for ind in POP:
                    Flags = [False] * len(VM.SPEEDS)  # 所有类型的新机器都未被使用
                    for v in range(len(self.useVMs)):
                        if len(ind.sol.Tasks_of_vm[v]) == 0:  # 空机器
                            type = self.useVMs[v].type
                            if Flags[type] == False:
                                Flags[type] = True
                            else:
                               continue
                        new_ind = partial_genome(wf)  # 新的解
                        # 指定new_sol使用机器v完成任务task
                        new_ind.evaluate_vm(task, v, ind)  # 使用机器v完成任务task
                        new_POP.append(new_ind)
                # 非支配排序，保留K个
                #new_POP = self.sort_POP(new_POP)  # 非支配排序
                new_POP = sorted(new_POP, key=functools.cmp_to_key(self.compare_based_makespan))  # 种群排序
                del new_POP[self.K:]  # 保留K个
                POP = new_POP  # 新POP
                for ind in POP:  # 创建新的sol
                    ind.alloc()
            # 结束处理当前task
            finish_task_num += 1
            if finish_task_num%100==0:
                print('   finish_task_num =',finish_task_num)
        # ----------------------  结束迭代  ------------------------
        # 计算
        return_sols = []
        for ind in POP:
            ind.sol.set_exit_task_assignment()
            ind.sol.cost = ind.sol.total_cost()
            ind.sol.makespan = ind.sol.total_maskspan()
            self.update_best_solution(ind.sol)
        return self.best_solution


    def update_best_solution(self,new_solution): #更新最优解
        is_update = False
        #对比self.best_solution和new_solution，new_solution更好则设置is_update = True
        if self.best_solution==None: #最优解尚未初始化
            is_update = True
        else:
            bs_cost = self.best_solution.cost #最优解cost
            ns_cost = new_solution.cost #新解cost
            bs_makespan = self.best_solution.makespan #最优解makespan
            ns_makespan = new_solution.makespan #新解makespan
            bs_feasiblity = bs_cost < self.wf.budget + self.tiny_num #最优解feasiblity
            ns_feasiblity = ns_cost < self.wf.budget + self.tiny_num #新解feasiblity
            if ns_feasiblity==True: #新解可行
                if bs_feasiblity==False or bs_makespan>ns_makespan+self.tiny_num: #最优解不可行或者其makespan更高
                    is_update = True
            else: #新解不可行
                if bs_feasiblity == False and bs_cost>ns_cost+self.tiny_num: ##最优解不可行 且 其cost更高
                    is_update = True
        #更新self.best_solution
        if is_update:
            self.best_solution = new_solution
            #print(self.best_solution.makespan,self.best_solution.cost,self.wf.budget)
            if self.is_print_information:
                print('update best solution')


    def print_pop(self, POP):  # 打印种群各个个体的指标，调试用
        print('----- POP information 1 ------')
        for i in range(len(POP)):
            print('ind', i, 'k = ',POP[i].get_fuzzy_dominance(),'[',POP[i].get_makespan(),',',POP[i].get_cost(), '] rank=', POP[i].get_rank(), ' cd =',
                  POP[i].get_crowding_distance())
        print('----------------------------')
        return

    def get_fes(self):  # 获得使用的函数评价次数
        return self.K * len(self.useVMs)

    def sort_POP(self, POP):  # 种群排序
        # 非支配排序,得到每个个体的rank值
        rank, f = self.fast_non_dominated_sort(POP)  # 非支配排序
        for i in range(len(POP)):
            POP[i].set_rank(rank[i])
        # 计算种群最大最小makespan以及cost,用于计算拥挤度时归一化
        ms_max = -float('inf')  # 种群最大makespan
        c_max = -float('inf')  # 种群最大cost
        ms_min = float('inf')  # 种群最小makespan
        c_min = float('inf')  # 种群最小cost
        for i in range(len(POP)):
            ms = POP[i].get_makespan()
            c = POP[i].get_cost()
            ms_max = max(ms_max, ms)
            ms_min = min(ms_min, ms)
            c_max = max(c_max, c)
            c_min = min(c_min, c)
        # 计算拥挤度
        POP = sorted(POP, key=functools.cmp_to_key(self.compare_based_RM))  # 种群排序,按照rank值(第一指标)以及makespan(第二指标)排序
        for i in range(len(POP)):
            cd = float('inf')  # POP[i]拥挤度
            if i == 0 or i == len(POP) - 1:
                cd = float('inf')
            elif POP[i].get_rank() != POP[i - 1].get_rank() or POP[i].get_rank() != POP[i + 1].get_rank():
                cd = float('inf')
            else:
                ms1 = POP[i - 1].get_makespan()
                ms2 = POP[i + 1].get_makespan()
                c1 = POP[i - 1].get_cost()
                c2 = POP[i + 1].get_cost()
                d_ms = abs((ms2 - ms1) / (ms_max - ms_min))  # 在makespan目标上的归一化距离
                d_c = abs((c1 - c2) / (c_max - c_min))  # 在cost目标上的归一化距离
                cd = d_ms + d_c  # 拥挤度
            POP[i].set_crowding_distance(cd)  # 保存cd
        # 计算Fuzzy dominance
        for i in range(len(POP)):
            #print('----------------------------------')
            k = 0 # a temporary variable to store the value of Fuzzy dominance
            for j in range(len(POP)):
                if i == j:
                    continue
                mu = 1
                if self.compare(POP[j],POP[i])==1 : #POP[j]支配POP[i]
                    ms1 = POP[i].get_makespan()
                    ms2 = POP[j].get_makespan()
                    mu1 = (ms1 - ms2) / (ms_max - ms_min)
                    mu1 = min(mu1,1)
                    mu1 = max(mu1,0)

                    c1 = POP[i].get_cost()
                    c2 = POP[j].get_cost()
                    mu2 = (c1 - c2) / (c_max - c_min)
                    mu2 = min(mu2, 1)
                    mu2 = max(mu2, 0)

                    mu = self.intersection(mu,mu1)
                    mu = self.intersection(mu,mu2)
                #print('  mu =',mu)
                    k = self.union(k,mu) #fan: 位置修正到if域里面
            #print('k =', k)
            POP[i].set_fuzzy_dominance(k)
            #print('----------------------------------')
            #print()
        # 种群排序,按照fuzzy_dominance值(第一指标)以及拥挤度(第二指标)排序
        POP = sorted(POP, key=functools.cmp_to_key(self.compare_based_FC))
        # 完成sort_POP，输出POP
        return POP


    def intersection(self,mu1,mu2): #论文未交代怎么求
        return (mu1 + mu2)/2  # 测试
        #return mu1 * mu2  # 参考文献:阿基米德 t 范数



    def union(self,k1,k2): #论文未交代怎么求
        return k1 + k2  # 测试
        #return k1 + k2 - k1 * k2 #参考文献

    def compare(self, ind1, ind2):  # 比较个体ind1和ind2, return 0: 同层, 1: ind1支配p2,  -1: ind2支配p1
        p1 = [ind1.get_makespan(), ind1.get_cost()]
        p2 = [ind2.get_makespan(), ind2.get_cost()]
        D = len(p1)
        p1_dominate_p2 = True  # p1是否支配p2
        p2_dominate_p1 = True  # p2是否支配p1
        for i in range(D):
            if p1[i] > p2[i]:
                p1_dominate_p2 = False
            if p1[i] < p2[i]:
                p2_dominate_p1 = False
        if p1_dominate_p2 == p2_dominate_p1:
            return 0
        return 1 if p1_dominate_p2 else -1

    def equal_objs(self, ind1, ind2):
        if math.isclose(ind1.get_makespan(),ind2.get_makespan()) and math.isclose(ind1.get_cost(),ind2.get_cost()):
            return True
        else:
            return False


    def compare_based_RM(self, ind1, ind2):  # 按照rank值(第一指标)以及makespan(第二指标)排序
        if ind1.get_rank() > ind2.get_rank():
            return 1
        elif ind1.get_rank() < ind2.get_rank():
            return -1
        else:
            if ind1.get_makespan() > ind2.get_makespan():
                return 1
            elif ind1.get_makespan() < ind2.get_makespan():
                return -1
            else:
                return 0

    def compare_based_makespan(self, ind1, ind2):  # 按照适应度值排序
        if ind1.get_makespan() > ind2.get_makespan():
            return 1
        else:
            return -1

    def compare_based_FC(self, ind1, ind2):  # 按照get_fuzzy_dominance值(第一指标)以及拥挤度(第二指标)排序
        if ind1.get_fuzzy_dominance() > ind2.get_fuzzy_dominance():
            return 1
        elif ind1.get_fuzzy_dominance() < ind2.get_fuzzy_dominance():
            return -1
        else:
            if ind1.get_crowding_distance() < ind2.get_crowding_distance():
                return 1
            elif ind1.get_crowding_distance() > ind2.get_crowding_distance():
                return -1
            else:
                return 0

    def fast_non_dominated_sort(self, P):  # 快速非支配排序
        P_size = len(P)
        n = np.full(shape=P_size, fill_value=0)  # 被支配数
        S = []  # 支配的成员
        f = []  # 0 开始每层包含的成员编号们
        rank = np.full(shape=P_size, fill_value=-1)  # 所处等级

        f_0 = []
        for p in range(P_size):
            n_p = 0
            S_p = []
            for q in range(P_size):
                if p == q:
                    continue
                cmp = self.compare(P[p], P[q])
                if cmp == 1:
                    S_p.append(q)
                elif cmp == -1:  # 被支配
                    n_p += 1
            S.append(S_p)
            n[p] = n_p
            if n_p == 0:
                rank[p] = 0
                f_0.append(p)
        f.append(f_0)

        i = 0
        while len(f[i]) != 0:  # 可能还有i+1层
            Q = []
            for p in f[i]:  # i层中每个个体
                for q in S[p]:  # 被p支配的个体
                    n[q] -= 1
                    if n[q] == 0:
                        rank[q] = i + 1
                        Q.append(q)
            i += 1
            f.append(Q)
        rank += 1
        return rank, f

    def cal_MPT(self):
        FT = [0] * self.wf.task_num  # 初始化结束时间
        ET = [0] * self.wf.task_num  # 初始化执行时间
        TT = [0] * self.wf.task_num  # 初始化传输时间
        TPT = [0] * self.wf.task_num  # 初始化总任务执行时间
        RFT = [0] * self.wf.task_num  # 初始化机器的结束时间
        BT = [0] * self.wf.task_num  # 初始化任务开始时间
        for i in range(self.wf.task_num):  # 遍历所有的任务，使所有的任务都租用新的机器，求出所有任务的开始时间和结束时间
            prosses_t = self.sorted_task_list[i]
            RFT[prosses_t] = 0
            BT[prosses_t] = RFT[prosses_t]
            if len(self.wf.parents[prosses_t]) != 0:  # 检查父节点并更新该任务的起始时间
                for parent in list(self.wf.parents[prosses_t]):
                    BT[prosses_t] = max(BT[prosses_t], FT[parent])
            ET[prosses_t] = self.wf.task_size[prosses_t] / VM.SPEEDS[VM.FASTEST]  # 更新任务处理时间
            TT[prosses_t] = sum(floatnum for floatnum in self.wf.TransDataSize[prosses_t] if
                                isinstance(floatnum, float)) / VM.NETWORK_SPEED  # 更新传输时间
            TPT[prosses_t] = ET[prosses_t] + TT[prosses_t]  # 更新机器总运行时间
            RFT[prosses_t] = BT[prosses_t] + TPT[prosses_t]  # 更新机器截止时间
            FT[prosses_t] = RFT[prosses_t]  # 更新任务的结束时间
        MPT = 1  # 初始化MPT
        for i in self.sorted_task_list:  # 遍历每一个任务
            if i == self.wf.entry_task:
                continue
            tmp_MPT = [1]  # 初始化当前任务的并行任务数，这是一个列表
            inter_section = []  # 交集
            operate_section = [BT[i], FT[i]]  # 当前任务的运行区间
            chack_list = [x for x in self.sorted_task_list if x != i]  # 其余需要检查的元素
            for j in chack_list:  # 检查其余的任务与当前任务在运行时间上是否存在交集
                chack_inter_section = [BT[j], FT[j]]  # 该检查任务的运行区间
                intersection_start = max(operate_section[0], chack_inter_section[0])
                intersection_end = min(operate_section[1], chack_inter_section[1])
                if round(intersection_start, 4) < round(intersection_end, 4):  # if 存在交集:
                    tmp_inter_section = [intersection_start, intersection_end]  # 这两个任务的交集
                    if inter_section.__len__() != 0:  # 检查交集集合里面的元素是否与新产生的交集存在交集，如果交集集合是空集，那么将该交集加入交集集合里
                        no_inter_section = True
                        for index, item in enumerate(inter_section):  # 遍历交集集合中的每一个元素
                            sub_tmp_inter_section_start = max(tmp_inter_section[0], item[0])
                            sub_tmp_inter_section_end = min(tmp_inter_section[1], item[1])
                            if round(sub_tmp_inter_section_start, 4) < round(sub_tmp_inter_section_end,
                                                                             4):  # if 交集集合里面的元素与当前交集存在交集:
                                inter_section[index] = [sub_tmp_inter_section_start,
                                                        sub_tmp_inter_section_end]  # 更新交集集合里面的元素
                                tmp_MPT[index] += 1  # 增加这个交集所代表的并行任务数
                                no_inter_section = False
                        if no_inter_section:
                            inter_section.append(chack_inter_section)  # 加入新的交集
                            tmp_MPT.append(2)  # 增加新的交集且将新的并行任务数初始化为2
                    else:
                        inter_section = [tmp_inter_section]  # 将该交集加入交集集合里
                        tmp_MPT = [2]  # 初始化并行任务数
            MPT = max(tmp_MPT) if max(tmp_MPT) > MPT else MPT
        return MPT


class partial_genome:  # 基因类，用于表示一个调度解
    wf = None  # 工作流
    sol = None  # 解码生成的完整调度解
    # 评价信息
    partial_makespan = None  #
    partial_cost = None  #
    rank = None  # 非支配排序的rank值
    crowding_distance = None  # 拥挤度
    fuzzy_dominance = None  # 模糊支配值

    def __init__(self, wf):
        self.wf = wf
        self.partial_makespan = 0.0
        self.partial_cost = 0.0

    def evaluate_vm(self, task, vj, ind):  # 使用机器vj处理task
        # 浅拷贝sol
        self.sol = ind.sol
        # 确定分配信息
        t_arr = [[] for i in range(3)]  # 存储分配信息浮点数部分：起[0]止[1]时间以及新增cost[2]
        v_arr = [[] for i in range(4)]  # 存储分配信息整数部分：[0]机器编号，[1]类型，[2]新旧(是否为老机器),[3]插入位置
        v_arr[0] = vj
        v_arr[1] = self.sol.UseVMs[vj].getType()
        v_arr[2] = 1  # 旧机器
        v_arr[3] = self.sol.cal_ft_and_addcost_for_last_processing(task, vj, t_arr)  # 确定t_arr和v_arr[3]
        # 记录分配信息
        self.task = task
        self.v_arr = v_arr
        self.t_arr = t_arr
        # 更新partial_makespan以及partial_cost
        self.partial_cost = ind.partial_cost + t_arr[2]
        self.partial_makespan = max(ind.partial_makespan, t_arr[1])

    def alloc(self):
        # 深拷贝sol并分配资源
        self.sol.wf = None
        self.sol = copy.deepcopy(self.sol)
        self.sol.wf = self.wf
        # 分配机器
        self.sol.alloc_front_task(self.task, self.v_arr, self.t_arr, None)

    def get_cost(self):  # 获取解的cost
        return self.partial_cost

    def get_makespan(self):  # 获取解的完工时间
        return self.partial_makespan

    def set_rank(self, r):  # 设置种群排名的rank值
        self.rank = r

    def get_rank(self):  # 获取解在非支配排序中的rank值
        return self.rank

    def set_crowding_distance(self, cd):  # 设置拥挤度
        self.crowding_distance = cd

    def get_crowding_distance(self):  # 获取crowding_distance
        return self.crowding_distance

    def set_fuzzy_dominance(self, fd):  # 设置拥挤度
        self.fuzzy_dominance = fd

    def get_fuzzy_dominance(self):  # 获取crowding_distance
        return self.fuzzy_dominance


