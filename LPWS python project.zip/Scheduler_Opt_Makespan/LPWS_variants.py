import random

from Scheduler_Opt_Makespan.GRPHEFT import GRPHEFT
from Setting.Scheduler import Scheduler
from Setting.Solution import Solution
from Setting.VM import VM
import numpy as np


def ini_func(wf):  # 初始化wf对应的解
    scheduler = GRPHEFT()
    ini_sol = scheduler.schedule(wf)
    return ini_sol

def get_feature(best_sol,FMode):
    if FMode==1:
        return best_sol.get_D()[0]
    elif FMode==2:
        return best_sol.get_T()[0]
    elif FMode==3:
        feature_list = best_sol.get_flex_time()
        for i in range(len(feature_list)):
            feature_list[i] = - feature_list[i]
        return feature_list
    else:
        feature_list = [None] * best_sol.wf.task_num
        for i in range(len(feature_list)):
            feature_list[i] = random.random()
        return feature_list

def build_sol(wf,FMode):
    # 初始化最优解best_sol
    best_sol = ini_func(wf)
    max_FES = wf.task_num * 100
    # 初始化迭代解S
    features = get_feature(best_sol,FMode)
    S = Solution(wf)  # 初始化解
    sorted_task_list = S.sort_tasks_based_topo_and_key(features)  # 任务排序
    S.build_HEFT(list(best_sol.leased_VM_types), list(best_sol.available_VM_hour), sorted_task_list)
    # 开始迭代
    FES = 2
    while (S.fitness_for_budget_constraints() < best_sol.fitness_for_budget_constraints() - 1E-8):
        best_sol = S
        # 构建新解
        features = get_feature(best_sol,FMode)
        S = Solution(wf)  # 初始化解
        sorted_task_list = S.sort_tasks_based_topo_and_key(features)  # 任务排序
        S.build_HEFT(list(best_sol.leased_VM_types), list(best_sol.available_VM_hour), sorted_task_list)
        # 完成一次迭代
        FES += 1
        if FES >= max_FES:
            break
    # 迭代结束
    return best_sol
class PlanB_1(Scheduler):
    def schedule(self, wf):  # 调度
        return build_sol(wf,1)

class PlanB_2(Scheduler):
    def schedule(self, wf):  # 调度
        return build_sol(wf,2)

class PlanB_3(Scheduler):
    def schedule(self, wf):  # 调度
        return build_sol(wf,3)

class PlanB_r(Scheduler):
    def schedule(self, wf):  # 调度
        return build_sol(wf,0)