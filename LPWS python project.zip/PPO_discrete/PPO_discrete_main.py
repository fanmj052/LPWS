import os
from os.path import exists
from os import mkdir
import torch
import numpy as np
import argparse
from PPO_discrete.environment import Environment
from PPO_discrete.normalization import Normalization, RewardScaling
from PPO_discrete.replaybuffer import ReplayBuffer
from PPO_discrete.ppo_discrete import PPO_discrete
import matplotlib.pyplot as plt
import pandas as pd

class PPO_DCS:
    def __init__(self, mode = "test"):
        parser = argparse.ArgumentParser("Hyperparameter Setting for PPO-discrete")

        # 状态 动作
        parser.add_argument("--state_dim", type=int, default=10, help=" 状态维度")
        parser.add_argument("--action_dim", type=int, default=5, help=" 动作维度")

        #训练参数
        parser.add_argument("--max_train_eps", type=int, default=10000, help=" Maximum number of training eps") #需要调参(重复训练多少次，越大时间越长）
        parser.add_argument("--evaluate_freq", type=float, default=5e3, help="Evaluate the policy every 'evaluate_freq' steps")
        parser.add_argument("--update_per_episode", type=int, default=5, help="每n集更新一次,训练环境越多n应越大") #需要调参(跑所有DAG设置5或者10）3,5,10,15,20
        parser.add_argument("--save_freq", type=int, default=20, help="Save frequency")
        parser.add_argument("--batch_size", type=int, default=204800, help="buffer最大容量")  #需要调整
        parser.add_argument("--mini_batch_size", type=int, default=64, help="Minibatch size")
        parser.add_argument("--hidden_width", type=int, default=64, help="The number of neurons in hidden layers of the neural network")
        parser.add_argument("--lr_a", type=float, default=3e-4, help="Learning rate of actor")
        parser.add_argument("--lr_c", type=float, default=3e-4, help="Learning rate of critic")
        parser.add_argument("--gamma", type=float, default=0.99, help="Discount factor")
        parser.add_argument("--lamda", type=float, default=0.95, help="GAE parameter")
        parser.add_argument("--epsilon", type=float, default=0.2, help="PPO clip parameter")
        parser.add_argument("--K_epochs", type=int, default=15, help="PPO parameter")
        parser.add_argument("--fig_freq", type=int, default=100, help="生成图片频率")
        parser.add_argument("--smooth_param", type=int, default=30, help="平滑参数")
        #可选trick
        parser.add_argument("--use_adv_norm", type=bool, default=True, help="Trick 1:advantage normalization")
        parser.add_argument("--use_state_norm", type=bool, default=False, help="Trick 2:state normalization")
        parser.add_argument("--use_reward_norm", type=bool, default=False, help="Trick 3:reward normalization")
        parser.add_argument("--use_reward_scaling", type=bool, default=True, help="Trick 4:reward scaling")
        parser.add_argument("--entropy_coef", type=float, default=0.01, help="Trick 5: policy entropy")
        parser.add_argument("--use_lr_decay", type=bool, default=True, help="Trick 6:learning rate Decay")
        parser.add_argument("--use_grad_clip", type=bool, default=True, help="Trick 7: Gradient clip")
        parser.add_argument("--use_orthogonal_init", type=bool, default=True, help="Trick 8: orthogonal initialization")
        parser.add_argument("--set_adam_eps", type=float, default=True, help="Trick 9: set Adam epsilon=1e-5")
        parser.add_argument("--use_tanh", type=float, default=True, help="Trick 10: tanh activation function")

        
        self.args = parser.parse_args()
        self.mode = mode
        self.agent = PPO_discrete(self.args)
        self.env = Environment(self.args, self.mode)
        if self.mode == "train":
            path = os.path.join(os.path.pardir, "result", "figures")
            if not exists(path):
                mkdir(path)
        else: #测试用，先读取模型，模型不存在会直接报错
            path = os.path.join(os.path.pardir,"PPO_discrete","saved_model","final_model")
            #path = os.path.join(os.path.pardir, "PPO_discrete", "saved_model", "best_score_model") 使用训练过程中得分最高的模型
            self.agent.actor.load_state_dict(torch.load(path))
            if self.args.use_state_norm: #状态标准化需要读取state_norm数据
                self.state_norm = Normalization(shape=self.args.state_dim)  # Trick 2:state normalization
    
    def train(self, seed = 2023):
        #-----------设置训练环境-----------#
        #env_ids = list(range(0,len(self.env.WFList)))
        env_ids = list(range(100))
        #env_ids = [0,20,40,60,80]
        #env_ids = list(range(0,100,20))+list(range(19,100,20))
        #env_ids = [60,70,79,80,90,99]
        #env_ids = [99]
        #---------------------------------#
        
        np.random.seed(seed)
        torch.manual_seed(seed)
        print("state_dim={}".format(self.args.state_dim))
        print("action_dim={}".format(self.args.action_dim))
        print("max_episodes={}".format(self.args.max_train_eps))
        
        result = np.zeros((self.args.max_train_eps, len(env_ids)))
        best_score = -10000
        data = np.zeros(self.args.max_train_eps)
        replay_buffer = ReplayBuffer(self.args)
    
        # Build a tensorboard
        #writer = SummaryWriter(log_dir='runs/PPO_discrete/env_{}_number_{}_seed_{}'.format(env_name, number, seed))
        if self.args.use_reward_norm:  # Trick 3:reward normalization
            reward_norm = Normalization(shape=1)
        elif self.args.use_reward_scaling:  # Trick 4:reward scaling
            reward_scaling = RewardScaling(shape=1, gamma=self.args.gamma)
        
        for total_eps in range(self.args.max_train_eps):
            for env_id in range(len(env_ids)): 
                s, mask = self.env.reset(env_ids[env_id])
                done = False
                episode_steps = 0
                ep_reward = 0
                action_record = []
                if self.args.use_state_norm:
                    s = self.state_norm(s)
                if self.args.use_reward_scaling:
                    reward_scaling.reset()

                while not done:
                    a, a_logprob = self.agent.choose_action(s, mask)  # Action and the corresponding log probability
                    s_, r, done, mask = self.env.step(a)
                    action_record.append(a)
                    ep_reward += r
        
                    if self.args.use_state_norm:
                        s_ = self.state_norm(s_)
                    if self.args.use_reward_norm:
                        r = reward_norm(r)
                    elif self.args.use_reward_scaling:
                        r = reward_scaling(r)
        
                    replay_buffer.store(s, a, a_logprob, r, s_, done, done, mask)
                    s = s_
                    episode_steps += 1

                #print("eps: ", total_eps, "ep_reward: ", round(ep_reward,3), "action: ", action_record)
                #print("eps: ", total_eps, "ep_reward: ", round(ep_reward,3))
                result[total_eps, env_id] = ep_reward
            data[total_eps] = np.mean(np.mean(result[max(0, total_eps - 30):total_eps + 1, :], 0), 0)
            if data[total_eps] > best_score:
                best_score = data[total_eps]
                path = os.path.join(os.path.pardir, "PPO_discrete", "saved_model", "best_score_model")
                torch.save(self.agent.actor.state_dict(), path)
                path = os.path.join(os.path.pardir, "result", "best_score_model")
                torch.save(self.agent.actor.state_dict(), path)
            print("eps: ", total_eps, "ep_reward: ", round(np.mean(result[total_eps, :]), 3))
            if np.mod(total_eps+1,self.args.update_per_episode)==0:
                self.agent.update(replay_buffer, total_eps)
                replay_buffer.count=0
            if np.mod(total_eps+1,self.args.fig_freq)==0:
                plt.plot(data[:total_eps+1],color='b',linewidth=1)
                path = os.path.join(os.path.pardir, "result", "figures", "episode_fig_"+str(total_eps+1)+".jpg")
                plt.title("eps "+str(total_eps+1))
                plt.savefig(path)


        path = os.path.join(os.path.pardir, "PPO_discrete", "saved_model", "final_model")
        torch.save(self.agent.actor.state_dict(), path)
        path = os.path.join(os.path.pardir, "result",  "final_model")
        torch.save(self.agent.actor.state_dict(), path)

        self.evaluate(env_ids)
        plt.plot(data,color='b',linewidth=1)
        path = os.path.join(os.path.pardir, "PPO_discrete", "train_fig.jpg")
        plt.savefig(path)
        path = os.path.join(os.path.pardir, "result", "train_fig.jpg")
        plt.savefig(path)

        result = pd.DataFrame(result)
        path = os.path.join(os.path.pardir, "PPO_discrete", "wf_train_result.csv")
        result.to_csv(path, header=None, index=False)
        path = os.path.join(os.path.pardir, "result", "wf_train_result.csv")
        result.to_csv(path, header=None, index=False)
    
    def evaluate(self, env_ids):
        result = np.zeros(len(env_ids))
        for env_id in range(len(env_ids)): 
            s, mask = self.env.reset(env_ids[env_id])
            done = False
            episode_steps = 0
            ep_reward = 0
            action_record = []
            if self.args.use_state_norm:
                s = self.state_norm(s)

            while not done:
                a = self.agent.choose_action(s, mask, True)  # Action and the corresponding log probability
                s_, r, done, mask = self.env.step(a)
                action_record.append(a)
                ep_reward += r
    
                if self.args.use_state_norm:
                    s_ = self.state_norm(s_)
    
                s = s_

            #print("evaluate ", "ep_reward: ", round(ep_reward,3), "action: ", action_record)
            print("evaluate ", "ep_reward: ", round(ep_reward,3))
            result[env_id] = ep_reward
        print(np.mean(result))
    
    def test(self, wf): #给定任务，返回一个解
        s, mask = self.env.reset(wf)
        done = False
        ep_reward = 0
        if self.args.use_state_norm:
            s = self.state_norm(s)
        while not done:
            a = self.agent.choose_action(s, mask, evaluate = True)  # Action and the corresponding log probability
            s_, r, done, mask = self.env.step(a)
            if self.args.use_state_norm:
                s_ = self.state_norm(s_)
            ep_reward += r
            s = s_
        return self.env.S

if __name__ == '__main__':
    runner = PPO_DCS("train")
    runner.train()
