# -*- coding: utf-8 -*-
"""
Created on Wed Nov  8 11:14:57 2023

@author: Lenovo
"""
import copy
import os
from functools import cmp_to_key
from Scheduler_Opt_cost.BaseDCS import BaseDCS
from Setting.Solution import Solution
from Setting.VM import VM
from Setting.Workflow import Workflow

tiny_num = 1e-8
class Environment:
    # 启发式策略设置
    sub_deadline_mode = "static" #static or dynamic
    avg_speed_mode = "fastest" #fastest affordable expect


    WFList = None #全部设置好deadline的wf
    ini_scheduler = None
    S = None #调度解
    activated_tasks = None #可选任务
    processed_task_count = None #当前处理了几个real task
    task_pool = None #候选任务
    task_indexs = None #候选任务在activated_tasks的位置
    SMI = [] #task_pool每个任务选择机器的信息
    leased_VM_types = None #机器类型
    remaining_in_degree = None #每个任务剩余入度
    #任务特征
    D0 = None
    Dn = None
    D = None
    T = None
    F = None
    marked = None


    def __init__(self, args, mode = "train"):
        self.mode = mode
        self.state_dim = args.state_dim
        self.action_dim = args.action_dim
        if self.mode == "train":
            #生成支持的workflow例子个数以及例子编号
            self.WFList = self.get_instances()
            #用于初始化解的调度器
        self.ini_scheduler = BaseDCS()

    def reset(self, x): #env_id：例子编号
        #生成workflow
        if self.mode == "train":
            wf = self.WFList[x]
        else:
            wf = x
        self.wf = wf
        #清空信息
        self.Infs = ""
        #创建初始解
        ini_sol = self.ini_scheduler.schedule(wf) #初始解
        self.S = Solution(wf)  #基于ini_sol生成的新解
        self.S.clear_solution()
        #self.S.is_print_information = True
        # 初始化每个任务出度
        task_num = self.S.wf.task_num
        self.remaining_in_degree = [[] for i in range(self.S.wf.task_num)]
        for i in range(task_num):
            self.remaining_in_degree[i] = len(self.S.wf.parents[i])
        # 确定候选机器类型
        self.leased_VM_types = VM.non_dominated_types()  # 获取所有非支配机器类型
        self.leased_VM_types.sort(key=cmp_to_key(VM.cmp_based_EffRate))  # 根据EffRate对机器类型排序,高EffRate排在前,同EffRate则高speed排在前
        #生成任务特征
        avg_speed = self.predict_avg_speed(ini_sol)
        self.D0 = wf.get_D0(avg_speed)  #每个任务开始到exit_task的预估关键路径长度,不忽略边传输时间
        self.Dn = wf.get_Dn(VM.SPEEDS[VM.FASTEST])  #每个任务开始到exit_task的预估关键路径长度，忽略边传输时间
        self.D = ini_sol.get_D()  # 每个任务开始到exit_task的实际关键路径长度
        self.T = ini_sol.get_T()  # 每个任务开始到exit_task的实际时间差
        self.F = ini_sol.get_flex_time()  # Flex time,表示每个任务推测多久开始仍然可满足deadline约束

        self.remaining_time = wf.deadline - ini_sol.makespan
        v = ini_sol.min_process_size_VM()
        tasks = ini_sol.Tasks_of_vm[v]
        self.marked = [0] * wf.task_num
        self.prolong_time = [0.0] * wf.task_num
        for t in tasks:
            self.marked[t] = 1
            self.prolong_time = self.remaining_time #尚未使用


        self.ini_sol = ini_sol
        # 开始处理任务, 处理entry_task
        self.activated_tasks = [self.S.wf.entry_task]
        self.S.remove_activated_task(self.activated_tasks, self.remaining_in_degree, 0)
        self.S.set_entry_task_assignment()
        # 初始化任务计数器
        self.processed_task_count = 0  # 处理完的任务个数
        # 调用get_state，返回当前状态
        return self.get_state()

    def predict_avg_speed(self,ini_sol):
        avg_speed = VM.SPEEDS[VM.FASTEST]
        if self.avg_speed_mode == "fastest":  # 用最快机器
            avg_speed = VM.SPEEDS[VM.FASTEST]
        elif self.avg_speed_mode == "affordable":  # 用费用不超过ini_sol.cost的最快机器
            budget = ini_sol.cost
            for ty in self.leased_VM_types:  # range(len(self.leased_VM_types-1),-1,-1)
                if VM.UNIT_COSTS[ty] <= budget + tiny_num:
                    avg_speed = VM.SPEEDS[ty]
                    break
        elif self.avg_speed_mode == "expect":  # 用速度超过ex_speed的最便宜机器
            ex_speed = self.wf.total_task_size() / self.wf.deadline
            for i in range(len(self.leased_VM_types) - 1, -1, -1):
                ty = self.leased_VM_types[i]
                if VM.SPEEDS[ty] >= ex_speed - tiny_num:
                    avg_speed = VM.SPEEDS[ty]
                    break
        else:
            print("avg_speed_mode ERROR")
            while True:
                pass
        return avg_speed
    def get_state(self): #获取状态
        pool_size = self.action_dim
        mask = None
        # 任务预筛选，最多保留pool_size个
        self.task_pool = None
        self.task_indexs = None
        if (len(self.activated_tasks) > pool_size):  # 候选任务超过pool_size个，取D0值最大的pool_size个
            # self.activated_tasks排序，前pool_size存放D0_s值最大的任务
            for i in range(pool_size):
                ti = self.activated_tasks[i]
                for j in range(i + 1, len(self.activated_tasks), 1):  # 遍历self.activated_tasks第i个单位之后的任务
                    tj = self.activated_tasks[j]
                    if self.D0[0][ti] < self.D0[0][tj]:  # 交换,保持self.activated_tasks[i]的D0_s比后续任务大
                        self.activated_tasks[i] = tj
                        self.activated_tasks[j] = ti
                        ti = self.activated_tasks[i]
            # 创建task_pool，存放self.activated_tasks前pool_size个单位
            self.task_pool = [self.activated_tasks[k] for k in range(pool_size)]
            self.task_indexs = [k for k in range(pool_size)]
            mask = [1 for i in range(pool_size)]  # 任务全部为可选任务
        else:  # 候选任务不超过pool_size个，取全部候选任务，不足pool_size个则补充虚拟任务
            # 创建task_pool，拷贝activated_tasks
            self.task_pool = list(self.activated_tasks)
            self.task_indexs = [k for k in range(len(self.activated_tasks))]
            mask = [1 for k in range(len(self.activated_tasks))] #activated_tasks对应的任务为real task
            while len(self.task_pool)<pool_size: #剩余任务为虚拟任务
                mask.append(0)
                self.task_pool.append(-1)
                self.task_indexs.append(-1)
        # 生成特征
        state = [] #状态
        self.SMI = [] #每个任务选择的机器
        #state.append(1.0 * (self.processed_task_count + 1) / (self.S.wf.task_num - 2))  # 要处理的第几个任务
        for t in self.task_pool:
            if t != -1:
                state.append(self.get_predict_st(t)/self.wf.deadline)  # D0 特征
                #state.append(self.marked[t]) #机器标识特征

                #state.append(self.Dn[0][t] / self.Dn[0][self.S.wf.entry_task])  # Dn 特征
                #state.append(self.D[0][t] / self.D[0][self.S.wf.entry_task])  # D1 特征
                #state.append(self.T[0][t] / self.T[0][self.S.wf.entry_task])  # T 特征
                # 选择机器
                sd = self.get_sub_deadline(t)
                select_vm_infomation = self.S.select_VM_based_subdeadline(t, sd, self.leased_VM_types)
                self.SMI.append(select_vm_infomation)
                add_cost = select_vm_infomation[1][2]/self.ini_sol.cost
                state.append(-add_cost)  # 回报：设置新增cost 特征
            else:
                state.append(0.0)
                state.append(0.0)
                #state.append(0.0)
                #state.append(0.0)
                #state.append(0.0)##############非法动作惩罚
                self.SMI.append([])
        #检查动作维度
        if len(state)!=self.state_dim:
            print('state_dim error!')
            while True:
                pass
        # 结束
        return state, mask

    def get_sub_deadline(self,t):
        if self.sub_deadline_mode == "static":
            maxD = self.D0[0][self.S.wf.entry_task]
            sd = ((maxD - self.D0[1][t]) / maxD) * self.wf.deadline
        else:
            max_at = self.S.max_arrive_time(t,-1)
            radio = (self.D0[0][t] - self.D0[1][t]) / self.D0[0][t]
            sd = max_at + (self.wf.deadline - max_at) * radio
        return sd

    def get_predict_st(self,t):
        maxD = self.D0[0][self.S.wf.entry_task]
        return ((maxD - self.D0[0][t]) / maxD) * self.wf.deadline
        '''
        if self.sub_deadline_mode == "static":
            maxD = self.D0[0][self.S.wf.entry_task]
            sd = ((maxD - self.D0[0][t]) / maxD) * self.wf.deadline
        else:
            max_at = self.S.max_arrive_time(t,-1)
            sd = max_at
        return sd
        '''

    '''
    def distance_to_ft(self,pt,t): #距离转换为结束时间
        radio = (self.D0[0][pt]-self.D0[1][t])/self.D0[0][pt]
        return self.S.ST[pt] + (self.wf.deadline-self.S.ST[pt])*radio
    
    def distance_to_st(self,pt,t): #距离转换为开始时间
        radio = (self.D0[0][pt]-self.D0[0][t])/self.D0[0][pt]
        return self.S.ST[pt] + (self.wf.deadline-self.S.ST[pt])*radio
    '''
    def step(self, action): #action表示选第几个任务
        # 确定任务
        select_task_index = self.task_indexs[action]  # 随机第action个候选任务
        select_task_id = self.activated_tasks[select_task_index]

        #print("sub-dl:",self.get_sub_deadline(select_task_id))
        # 分配机器
        select_vm_infomation = self.SMI[action]
        self.S.alloc_front_task(select_task_id, select_vm_infomation[0], select_vm_infomation[1], None)
        '''
        # 记录分配信息
        inf = []
        v_arr = select_vm_infomation[0]
        t_arr = select_vm_infomation[1]
        vm = -1
        if v_arr[2] == 1:
            vm = v_arr[0]
        else:
            vm = len(self.S.UseVMs)-1
        if v_arr[2] == 1:
            inf = "assign old vm"+str(vm)+"(type = "+ str(self.S.UseVMs[vm].getType())+")"+ " to task "+ str(select_task_id)
        else:
            inf = "assign new vm"+str(vm)+"(type = "+str(self.S.UseVMs[vm].getType())+")"+" to task "+str(select_task_id)
        self.Infs += inf+"\n"
        '''
        # 更新信息
        self.processed_task_count = self.processed_task_count + 1
        self.S.remove_activated_task(self.activated_tasks, self.remaining_in_degree, select_task_index)
        # 回报

        reward = -select_vm_infomation[1][2]/self.ini_sol.cost #回报设置为负的新增cost
        # 确定state, mask, done
        state = [0]*self.state_dim
        mask = [1]*self.action_dim
        done = 0  # 是否结束,1代表结束,0代表不结束
        #   判断是否调度没结束
        if len(self.activated_tasks) == 1 and self.activated_tasks[0] == self.S.wf.exit_task: #调度结束
            self.S.set_exit_task_assignment()
            # 计算cost
            self.S.cost = self.S.total_cost()
            # 计算makespan
            self.S.makespan = self.S.total_maskspan()
            done = 1
        else:
            state, mask = self.get_state()
        return state, reward, done, mask

    def get_instances(self):
        # ----------------------------  工作流设置  ----------------------------
        WorkflowFile = 'Workflow_data'
        SIZES = (30,)
        WORKFLOWS = ("CyberShake", "Epigenomics", "LIGO", "Montage", "Sipht") #全部工作流
        # ----------------------------  deadline_factor设置  ----------------------------
        DF_START = 1 #从1第一个等分点开始
        DF_INCR = 1 #间隔为1
        DF_END = 20 #10等分
        # ----------------------------  开始生成instance  ----------------------------
        WFList = [] #存储所有wf
        deadlineNum = (int)((DF_END - DF_START) / DF_INCR + 1 + tiny_num)  # 每个benchmark的budget约束个数
        for workflow in WORKFLOWS:  # 遍历每一个工作流
            # 遍历当前工作流类的每一个size
            for si in range(len(SIZES)):
                size = SIZES[si]  # 任务数
                wf_path = os.path.join(os.path.pardir, WorkflowFile, workflow + '_' + str(size) + '.txt')  # 工作流读取路径
                wf0 = Workflow(wf_path)  # 构建wf
                base_ms = wf0.fast_schedule_makespan  # 获取makespan下界
                # 遍历每一个deadline
                for di in range(deadlineNum):
                    wf = copy.deepcopy(wf0) #深拷贝
                    deadlineFactor = DF_START + DF_INCR * di
                    deadlineFactor = max(deadlineFactor, 1.5)
                    deadline = base_ms * deadlineFactor + tiny_num  # deadline约束值
                    wf.set_deadline(deadline)  # 设置deadline约束值
                    WFList.append(wf)
        #结束
        print('end func get_instances')
        return WFList
