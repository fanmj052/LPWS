import os

from Scheduler_Opt_Makespan.GRPHEFT import GRPHEFT
from Scheduler_Opt_cost.BaseDCS import BaseDCS
from Scheduler_Opt_cost.RL_DCS import RL_DCS
from Scheduler_Opt_Makespan.LPWS import LPWS, PlanB_test
from Scheduler_Opt_Makespan.LPWS_variants import *
from Scheduler_Opt_Cost_Makespan.ExampleMOScheduler import ExampleMOScheduler
from Scheduler_Opt_Cost_Makespan.MOELS import MOELS
from Scheduler_Opt_Cost_Makespan.PlanC import PlanC
from Scheduler_Opt_Cost_Makespan.MOACS import MOACS
from Scheduler_Opt_Cost_Makespan.MOHEFT import MOHEFT
from Scheduler_Opt_Cost_Makespan.KASMA import KASMA
from Scheduler_Opt_Cost_Makespan.HCMFOAA import HCMFOAA
from Scheduler_Opt_Cost_Makespan.PlanC_rS1 import PlanC_rS1
from Scheduler_Opt_Makespan.GA import GA
from Scheduler_Opt_Makespan.MOHEFT_opt_makespan import MOHEFT_opt_makespan


tiny_num = 1E-8

def get_method(M): #重新构建一个M对应的调度器
    method_name = M.__class__.__name__
    return globals()[method_name]()

def get_Solution_ExcelFilePath(M): #获取调度算法M的写入文件路径
    method_name = M.__class__.__name__
    Solution_ExcelFilePath = os.path.join(os.path.pardir,'result', method_name + '_solution.xlsx')
    return Solution_ExcelFilePath

def three_D_array(a,b,c): #构建一个a×b×c的三维数组,数组各元素为空
    return [[[[] for i in range(c)] for i in range(b) ] for i in range(a)]