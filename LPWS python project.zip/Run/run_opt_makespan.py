import time
import random

from joblib import Parallel, delayed

from Run import *
from Scheduler_Opt_Makespan.MOHEFT_opt_makespan import MOHEFT_opt_makespan
from Scheduler_Opt_Makespan.GA import GA
from Scheduler_Opt_Makespan.LPWS import LPWS, PlanB_test
from Scheduler_Opt_Makespan.LPWS_variants import PlanB_1, PlanB_2, PlanB_3, PlanB_r
from Setting.Workflow import Workflow
from Scheduler_Opt_Makespan.GRPHEFT import GRPHEFT
from Tool.ExcelManage import *

#----------------------------  工作流设置  ----------------------------
WorkflowFile = 'Workflow_data'
#SIZES = (30,)
SIZES = (1000,)
#SIZES = (30,50)
#SIZES = (30,50,100,1000)
WORKFLOWS = ("CyberShake", "Epigenomics", "LIGO", "Montage", "Sipht")
#WORKFLOWS = ("CyberShake",)
#WORKFLOWS = ("CyberShake","LIGO")
DF_START = 1
DF_INCR = 1
DF_END = 10
#----------------------------  算法设置  ----------------------------
REPEATED_TIMES = 1
#METHODS = (GRPHEFT(),PlanB_1(),PlanB_2(),PlanB_3(),PlanB_r())
#METHODS = (GRPHEFT(),PlanB(),)
#METHODS = (PlanB(),PlanB_test(),)
#METHODS = (MOHEFT_opt_makespan(),)
METHODS = (LPWS(),)
#----------------------------  输出设置  ----------------------------
isParallel = False #True False
parallel_jobs = 8
isPrintSolution = True #True or False
OUTPUT_LOCATION = os.path.join(os.path.pardir, 'result')
Summary_ExcelFilePath = os.path.join(OUTPUT_LOCATION,'summary.xlsx')
#-------------------------------------------------------------------


# ----------------------------  开始运行  ----------------------------
def main(): #主程序
    budgetNum = (int) ((DF_END - DF_START) / DF_INCR + 1+tiny_num) #每个benchmark的budget约束个数
    for workflow in WORKFLOWS: #遍历每一个工作流
        successResult = three_D_array(budgetNum,len(METHODS),len(SIZES)) #每次运行解是否可行
        NTResult = three_D_array(budgetNum,len(METHODS),len(SIZES)) #每次运行makespan归一化值
        RunTimeResult = three_D_array(budgetNum,len(METHODS),len(SIZES)) #每次运行CPU运行时间
        budget_array = [[[] for i in range(len(SIZES))] for i in range(budgetNum)] #每个benchmark的budget
        MS_LB = [[] for i in range(len(SIZES))] #当前工作流不同size的makespan下限
        # 遍历当前工作流类的每一个size
        for si in range(len(SIZES)):
            size = SIZES[si] #任务数
            wf_path = os.path.join(os.path.pardir, WorkflowFile, workflow + '_' + str(size) + '.txt') #工作流读取路径
            wf = Workflow(wf_path) #构建wf
            MS_LB[si] = wf.fast_schedule_makespan #获取makspan下限
            base_cost = wf.cheap_schedule_cost # 获取budget下界
            # 遍历每一个budget
            for di in range(budgetNum):
                budget = base_cost * (di + 1) + tiny_num #budget约束值
                #budget = max(budget / 5.0, 0.044001) #测试！！！
                wf.set_budget(budget) #设置budget约束值
                budget_array[di][si] = budget #记录budget约束值
                # 遍历每一个算法
                for mi in range(len(METHODS)):
                    method = get_method(METHODS[mi]) #第mi个算法
                    methodName = METHODS[mi].__class__.__name__ #算法名
                    Solution_ExcelFilePath = get_Solution_ExcelFilePath(METHODS[mi]) #解的写入Excel存储位置
                    sheetName = workflow + "_" + str(size) #解在Excel存储的sheet
                    #重复运行REPEATED_TIMES次
                    if isParallel == False: #串行运行
                        for timeI in range(REPEATED_TIMES): #重复运行REPEATED_TIMES次
                            # 调度前: 打印信息,记录开始时间
                            print("\n"+workflow+str(size)+","+methodName+", di = "+str(di)+"/"+str(budgetNum-1)+", run = "+str(timeI)+"/"+str(REPEATED_TIMES-1))
                            time_start = time.process_time()  # 记录开始时间
                            random.seed(timeI)  # 设置随机种子为运行次数，方便复现实验结果
                            np.random.seed(timeI)
                            #调度
                            sol = method.schedule(wf)
                            #调度后: 记录结束时间，检查解,无误则写入解
                            time_end = time.process_time()  # 记录结束时间
                            runTime = time_end - time_start  # 计算的时间差为程序的执行时间，单位为秒
                            if sol.check_solution()==False: #检查解是否满足基本约束，不满足则程序停滞在死循环中等待检查
                                print('sol is not correct！！！！！')
                                while True: #死循环
                                    pass
                            isSatisfied = sol.is_satisfied_budget_constraint(budget) #解是否满足budget_constraint
                            cost = sol.total_cost() #解的cost值
                            maskspan = sol.total_maskspan() #解的makespan
                            #   写入解
                            print("\tisSatisfied:", isSatisfied)
                            print("\tcost:", cost)
                            print("\tmaskspan:", maskspan)
                            print("\truntime:",runTime)
                            if isPrintSolution:
                                budgetFactor = DF_START + DF_INCR * di
                                writeToExcel(Solution_ExcelFilePath, sheetName, budgetFactor, budget, methodName, mi, sol, "Budget")
                            #   记录解信息
                            successResult[di][mi][si].append(isSatisfied) #记录可行性
                            NTResult[di][mi][si].append(maskspan/wf.fast_schedule_makespan) #记录makespa归一化值
                            RunTimeResult[di][mi][si].append(runTime) #记录运行时间
                    else:  #并行运行
                        print("\n" + workflow + str(size) + "," + methodName + ", di = " + str(di) + "/" + str(
                            budgetNum - 1))
                        sols = Parallel(n_jobs=parallel_jobs)(delayed(schedule_one)(methodName,timeI,workflow,size,di,budgetNum,REPEATED_TIMES) for timeI in range(REPEATED_TIMES))
                        for timeI in range(REPEATED_TIMES):
                            sol = sols[timeI]
                            isSatisfied = sol.is_satisfied_budget_constraint(budget)  # 解是否满足budget_constraint
                            cost = sol.total_cost()  # 解的cost值
                            maskspan = sol.total_maskspan()  # 解的makespan
                            if isPrintSolution:
                                budgetFactor = DF_START + DF_INCR * di
                                writeToExcel(Solution_ExcelFilePath, sheetName, budgetFactor, budget, methodName, mi, sol,
                                             "Budget")
                            #   记录解信息
                            successResult[di][mi][si].append(isSatisfied)  # 记录可行性
                            NTResult[di][mi][si].append(maskspan / wf.fast_schedule_makespan)  # 记录makespa归一化值
                            RunTimeResult[di][mi][si].append(sol.runTime)  # 记录运行时间


        # 写入记录的信息,运行结束
        is_write_max_min = True
        write_makespan_summary_excel(Summary_ExcelFilePath, successResult, NTResult, METHODS, SIZES, workflow, budget_array, REPEATED_TIMES, RunTimeResult, 1.0, MS_LB,'budget','NT',is_write_max_min)
    print('end run')
    return
# ----------------------------  结束运行  ----------------------------


def schedule_one(methodName,timeI,workflow,size,di,budgetNum,REPEATED_TIMES):
    # 调度前: 打印信息,记录开始时间
    method = LPWS()
    time_start = time.process_time()  # 记录开始时间
    random.seed(timeI)  # 设置随机种子为运行次数，方便复现实验结果
    np.random.seed(timeI)
    # 调度
    sol = method.schedule(wf)
    # 调度后: 记录结束时间，检查解,无误则写入解
    time_end = time.process_time()  # 记录结束时间
    sol.runTime = time_end - time_start  # 计算的时间差为程序的执行时间，单位为秒
    if sol.check_solution() == False:  # 检查解是否满足基本约束，不满足则程序停滞在死循环中等待检查
        print('sol is not correct！！！！！')
        while True:  # 死循环
            pass
    return sol


if __name__ == '__main__':
    main()
