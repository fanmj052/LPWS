import os
import openpyxl

from Run import get_method
from Setting.VM import VM
import math


def write_MC_summary_information(OUTPUT_LOCATION, METHODS, SIZES, workflow, REPEATED_TIMES, TResult, CResult,
                                 RunTimeResult, FesResult):  # 写入当前workflow在各个METHODS求解结果的makespan和cost信息
    if not os.path.exists(OUTPUT_LOCATION):  # 创建写入文件夹
        os.mkdir(OUTPUT_LOCATION)
    for mi in range(len(METHODS)):  # 遍历每个算法
        method = get_method(METHODS[mi])  # 第mi个算法
        methodName = METHODS[mi].__class__.__name__  # 算法名
        excel_path = os.path.join(OUTPUT_LOCATION, methodName + '.xlsx')  # 写入xlsx路径
        if not os.path.exists(excel_path):  # 创建工作簿
            data = openpyxl.Workbook()
            data.save(excel_path)  # 保存
        for si in range(len(SIZES)):  # 遍历每一个size
            size = SIZES[si]  # 任务数
            sheet_name = workflow + "_" + str(size)  # 解在Excel存储的sheet
            # 创建sheet
            data = openpyxl.load_workbook(excel_path)
            table = None
            if sheet_name not in data.sheetnames:
                default_sheet = 'Sheet'
                if default_sheet in data.sheetnames:
                    data[default_sheet].title = sheet_name
                else:
                    data.create_sheet(sheet_name)  # 添加页
            table = data[sheet_name]  # 获得指定名称页
            for timeI in range(REPEATED_TIMES):  # 重复运行REPEATED_TIMES次
                # 写入到工作簿
                table.cell(3 * timeI + 1, 1, 'run ' + str(timeI + 1) + ':')
                table.cell(3 * timeI + 2, 1, 'makespan')
                table.cell(3 * timeI + 3, 1, 'cost')

                table.cell(3 * timeI + 1, 2, 'fes = ' + str(FesResult[mi][si][timeI]))  # 评价次数
                table.cell(3 * timeI + 1, 3, str(RunTimeResult[mi][si][timeI]) + 's')  # 运行时间

                for j in range(len(TResult[mi][si][timeI])):
                    table.cell(3 * timeI + 2, j + 2, TResult[mi][si][timeI][j])
                    table.cell(3 * timeI + 3, j + 2, CResult[mi][si][timeI][j])
            data.save(excel_path)


def write_MC_solution_information(OUTPUT_LOCATION, METHODS, SIZES, workflow,
                                  SolsResult):  # 写入当前workflow在各个METHODS求解结果的makespan和cost信息
    if not os.path.exists(OUTPUT_LOCATION):  # 创建写入文件夹
        os.mkdir(OUTPUT_LOCATION)
    for mi in range(len(METHODS)):  # 遍历每个算法
        method = get_method(METHODS[mi])  # 第mi个算法
        methodName = method.__class__.__name__  # 算法名
        excel_path = os.path.join(OUTPUT_LOCATION, 'Solution_' + methodName + '.xlsx')  # 写入xlsx路径
        if not os.path.exists(excel_path):  # 创建工作簿
            data = openpyxl.Workbook()
            data.save(excel_path)  # 保存
        for si in range(len(SIZES)):  # 遍历每一个size
            size = SIZES[si]  # 任务数
            sheet_name = workflow + "_" + str(size)  # 解在Excel存储的sheet
            # 创建sheet
            data = openpyxl.load_workbook(excel_path)
            table = None
            if sheet_name not in data.sheetnames:
                default_sheet = 'Sheet'
                if default_sheet in data.sheetnames:
                    data[default_sheet].title = sheet_name
                else:
                    data.create_sheet(sheet_name)  # 添加页
            table = data[sheet_name]  # 获得指定名称页
            timeI = 0
            row = -3
            for sols in SolsResult[mi][si]:  # 获取每次运行的解集
                timeI += 1
                row += 3
                # 写入到工作簿
                row += 1
                table.cell(row, 1, 'run ' + str(timeI) + ':')
                index = 0  # 解编号
                for sol in sols:
                    index += 1
                    row += 2
                    # 第一行：解编号以及目标值
                    table.cell(row, 1, 'sol ' + str(index) + ':')
                    table.cell(row, 2, "[makespan=" + str(round(sol.total_maskspan(), 3)) + ", cost=" + str(
                        round(sol.total_cost(), 3)) + "]")

                    # 写入VM类型计数
                    row += 1
                    type_num = [0 for i in range(len(VM.UNIT_COSTS))]
                    type_count = 0
                    for v in range(len(sol.UseVMs)):
                        if len(sol.Tasks_of_vm[v]) == 0:  # 剔除空机器
                            continue
                        vm = sol.UseVMs[v]
                        type_num[vm.getType()] = type_num[vm.getType()] + 1
                    for i in reversed(range(len(VM.UNIT_COSTS))):
                        if type_num[i] > 0:
                            table.cell(row, type_count + 1, "type=" + str(i) + ", count = " + str(type_num[i]))
                            type_count = type_count + 1
                    # 写入VM工作起止时间以及处理的任务
                    #   先求task_rank
                    task_list = []
                    for t in range(sol.wf.task_num):
                        task_list.append(t)
                    for i in range(len(task_list)):
                        for j in range(i + 1, len(task_list)):
                            if sol.ST[task_list[j]] < sol.ST[task_list[i]]:
                                t = task_list[i]
                                task_list[i] = task_list[j]
                                task_list[j] = t
                    task_rank = [[] for i in task_list]
                    for i in range(len(task_list)):
                        t = task_list[i]
                        # print("   ",solution.ST[t])
                        if i == 0:
                            task_rank[t] = 1
                        else:
                            lt = task_list[i - 1]
                            if math.isclose(sol.ST[lt], sol.ST[t]):
                                task_rank[t] = task_rank[lt]
                            else:
                                task_rank[t] = task_rank[lt] + 1
                    #   逐个VM写入
                    for v in range(len(sol.UseVMs)):
                        if len(sol.Tasks_of_vm[v]) == 0:  # 剔除空机器
                            continue
                        row += 1
                        LST = round(sol.vm_boot_time(v), 3)
                        LET = round(sol.vm_shutdown_time(v), 3)
                        type = sol.UseVMs[v].getType()
                        table.cell(row, 1, "VM " + str(v) + "[id=" + str(v) + ",type=" + str(type) + ",LST=" + str(
                            LST) + ",LET=" + str(LET) + "]")

                        for t in sol.Tasks_of_vm[v]:
                            st = round(sol.ST[t], 3)
                            ft = round(sol.FT[t], 3)
                            table.cell(row, 2 + task_rank[t], "t" + str(t) + "[" + str(st) + "," + str(ft) + "]")
            data.save(excel_path)


# 写入makespan结果到summary表
def write_makespan_summary_excel(path, successResult, MSResult, METHODS, SIZES, workflow, budget_array, REPEATED_TIMES,
                                 RunTimeResult, minDi, MS_LB, constr_name, obj_name, is_write_max_min):
    default_sheet = 'Sheet'
    # 创建Workbook
    if os.path.exists(path) == False:
        data = openpyxl.Workbook()  # 新建工作簿
        data.save(path)  # 保存
    for si in range(len(SIZES)):
        size = SIZES[si]
        sheet_name = "" + str(size) + " tasks"
        # 创建sheet
        data = openpyxl.load_workbook(path)
        if sheet_name not in data.sheetnames:
            if default_sheet in data.sheetnames:
                data[default_sheet].title = sheet_name
            else:
                data.create_sheet(sheet_name)  # 添加页
            table = data[sheet_name]  # 获得指定名称页
            row1 = 1
            row2 = 2
            col_num = 1
            table.cell(row1, col_num, '')  # 行，列，值 这里是从1开始计数的
            col_num = col_num + 1
            table.cell(row1, col_num, 'benchmark')
            col_num = col_num + 1
            table.cell(row1, col_num, constr_name + ' factor')
            col_num = col_num + 1
            table.cell(row1, col_num, constr_name)
            col_num = col_num + 1
            table.cell(row1, col_num, 'LB')
            col_num = col_num + 1
            for m in range(len(METHODS)):
                table.cell(row1, col_num, '')
                table.cell(row2, col_num, 'SR')
                col_num = col_num + 1

                if is_write_max_min:
                    table.cell(row1, col_num, '')
                    table.cell(row2, col_num, 'min_' + obj_name)
                    col_num = col_num + 1

                table.cell(row1, col_num, METHODS[m].__class__.__name__)
                table.cell(row2, col_num, obj_name)
                col_num = col_num + 1

                if is_write_max_min:
                    table.cell(row1, col_num, '')
                    table.cell(row2, col_num, 'max_' + obj_name)
                    col_num = col_num + 1

                table.cell(row1, col_num, '')
                table.cell(row2, col_num, 'RT')
                col_num = col_num + 1
            data.save(path)
        # 追加写入到sheet
        table = data[sheet_name]
        nrows = table.max_row  # 获得行数
        row_num = nrows

        for di in range(len(budget_array)):
            row_num = row_num + 1
            col_num = 1

            table.cell(row_num, col_num).value = row_num - 2
            col_num = col_num + 1

            table.cell(row_num, col_num).value = workflow
            col_num = col_num + 1

            table.cell(row_num, col_num).value = max(di + 1.0, minDi)
            col_num = col_num + 1

            table.cell(row_num, col_num).value = budget_array[di][si]
            col_num = col_num + 1

            table.cell(row_num, col_num).value = MS_LB[si]
            col_num = col_num + 1

            for m in range(len(METHODS)):
                avg_sr = 0.0
                max_ms = -1.0
                avg_ms = 0.0
                min_ms = float('inf')
                avg_rt = 0.0
                success_num = 0

                srlist = successResult[di][m][si]
                mrlist = MSResult[di][m][si]
                rt_list = RunTimeResult[di][m][si]
                for k in range(len(srlist)):
                    s = float(srlist[k])
                    ms = mrlist[k]
                    rt = rt_list[k]
                    if s > 1 - 1E-8:
                        avg_sr = avg_sr + s
                        avg_ms = avg_ms + ms
                        max_ms = max(max_ms, ms)
                        min_ms = min(min_ms, ms)
                        success_num = success_num + 1
                    avg_rt = avg_rt + rt
                # 取平均值
                avg_sr /= REPEATED_TIMES
                if success_num > 0:
                    avg_ms = avg_ms / success_num
                else:
                    avg_ms = -999
                avg_rt /= REPEATED_TIMES
                # 精度调整,保留小数点后若干位
                avg_sr = round(avg_sr, 3)
                min_ms = round(min_ms, 6)
                avg_ms = round(avg_ms, 6)
                max_ms = round(max_ms, 6)
                avg_rt = round(avg_rt, 8)
                # 写入文件
                table.cell(row_num, col_num).value = avg_sr
                col_num = col_num + 1
                if (avg_ms < -990):
                    if is_write_max_min:
                        table.cell(row_num, col_num).value = 'NaN'
                        col_num = col_num + 1

                    table.cell(row_num, col_num).value = 'NaN'
                    col_num = col_num + 1

                    if is_write_max_min:
                        table.cell(row_num, col_num).value = 'NaN'
                        col_num = col_num + 1
                else:
                    if is_write_max_min:
                        table.cell(row_num, col_num).value = min_ms
                        col_num = col_num + 1

                    table.cell(row_num, col_num).value = avg_ms
                    col_num = col_num + 1

                    if is_write_max_min:
                        table.cell(row_num, col_num).value = max_ms
                        col_num = col_num + 1
                table.cell(row_num, col_num).value = avg_rt
                col_num = col_num + 1

        data.save(path)


# 写入解信息到path中
def writeToExcel(path, sheet_name, budgetFactor, budget, methodTitle, mi, solution, constraintFactorName):
    default_sheet = 'Sheet'
    # 创建Workbook
    if os.path.exists(path) == False:
        data = openpyxl.Workbook()  # 新建工作簿
        data.save(path)  # 保存
    # 创建sheet
    data = openpyxl.load_workbook(path)
    if sheet_name not in data.sheetnames:
        if default_sheet in data.sheetnames:
            data[default_sheet].title = sheet_name
        else:
            data.create_sheet(sheet_name)  # 添加页
    # 写入解信息
    table = data[sheet_name]  # 获得指定名称页
    nrows = table.max_row  # 获得行数
    row_num = nrows + 2
    #   写入约束程度
    table.cell(row_num, 1).value = "约束程度" + str(
        round(budgetFactor * 1.0, 1)) + " [" + constraintFactorName + "=" + str(budget) + "]"
    row_num = row_num + 1
    #   写入当前方法求得的cost和makespan
    table.cell(row_num, 1).value = methodTitle + "的解" + "  " + "[cost=" + str(
        round(solution.total_cost(), 3)) + ", makespan=" + str(round(solution.total_maskspan(), 3)) + "]"
    #   写入VM类型计数
    type_num = [0 for i in range(len(VM.UNIT_COSTS))]
    type_count = 1
    for vm in solution.UseVMs:
        type_num[vm.getType()] = type_num[vm.getType()] + 1
    for i in reversed(range(len(VM.UNIT_COSTS))):
        if type_num[i] > 0:
            table.cell(row_num, type_count + 1).value = "type=" + str(i) + ", count = " + str(type_num[i])
            type_count = type_count + 1
    row_num = row_num + 1

    #   写入VM工作起止时间以及处理的任务
    #       先求task_rank
    task_list = []
    for t in range(solution.wf.task_num):
        task_list.append(t)
    for i in range(len(task_list)):
        for j in range(i + 1, len(task_list)):
            if solution.ST[task_list[j]] < solution.ST[task_list[i]]:
                t = task_list[i]
                task_list[i] = task_list[j]
                task_list[j] = t
    task_rank = [[] for i in task_list]
    for i in range(len(task_list)):
        t = task_list[i]
        # print("   ",solution.ST[t])
        if i == 0:
            task_rank[t] = 1
        else:
            lt = task_list[i - 1]
            if math.isclose(solution.ST[lt], solution.ST[t]):
                task_rank[t] = task_rank[lt]
            else:
                task_rank[t] = task_rank[lt] + 1
    #       逐个VM写入
    for v in range(len(solution.UseVMs)):
        if len(solution.Tasks_of_vm[v])==0:
            continue
        LST = round(solution.vm_boot_time(v), 3)
        LET = round(solution.vm_shutdown_time(v), 3)
        type = solution.UseVMs[v].getType()
        table.cell(row_num, 1).value = "VM " + str(v) + "[id=" + str(v) + ",type=" + str(type) + ",LST=" + str(
            LST) + ",LET=" + str(LET) + "]"

        for t in solution.Tasks_of_vm[v]:
            st = round(solution.ST[t], 3)
            ft = round(solution.FT[t], 3)
            table.cell(row_num, 2 + task_rank[t]).value = "t" + str(t) + "[" + str(st) + "," + str(ft) + "]"
        row_num = row_num + 1

    # 保存
    data.save(path)
