from PPO_discrete.PPO_discrete_main import PPO_DCS
from Setting.Scheduler import Scheduler
from Setting.Solution import Solution
from Setting.VM import VM


class RL_DCS(Scheduler): #基本Deadline-constrainted Scheduler, 优化cost

    pool_size = 3 #最多考虑3个任务

    best_sol = None
    runner = None
    is_print_information = False  # 是否打印过程信息 True or False
    max_FES = None

    def __init__(self):
        super().__init__()

    def schedule(self, wf):
        #初始化
        self.runner = PPO_DCS("test")
        self.best_sol = self.runner.test(wf)
        return self.best_sol




