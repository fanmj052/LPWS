from Setting.Scheduler import Scheduler
from Setting.Solution import Solution
from Setting.VM import VM


class BaseDCS(Scheduler): #基本Deadline-constrainted Scheduler, 优化cost

    is_print_information = False  # 是否打印过程信息 True or False

    def __init__(self):
        super().__init__()

    def schedule(self, wf):
        #初始化
        self.wf = wf
        S = Solution(wf)  # 初始化解
        #任务排序

        D0_sf = self.wf.get_D0(VM.SPEEDS[VM.FASTEST])  # 计算任务优先级
        D0_s = D0_sf[0]
        D0_f = D0_sf[1]
        sorted_task_list = S.sort_tasks_based_topo_and_key(D0_s) # 任务排序
        #构建解

        #S.build_dynamincally_satDL_minCost()

        S.build_satDL_minCost(sorted_task_list,D0_s,D0_f) #sub-deadline约束下构建解

        return S




