import math
class VM:

    ##类变量
    LAUNCH_TIME = 0.0 #VM开机时间
    NETWORK_SPEED = 20.0 #带宽20MB
    SPEEDS = (1.0, 2.0, 3.0, 4.0, 6.5, 8.0, 13.0, 26.0) #不同类型的机器速度
    UNIT_COSTS = (0.044, 0.087, 0.067, 0.175, 0.133, 0.35, 0.266, 0.532) #各个类型机器的单位时段cost
    INTERVAL = 3600.0 #inetrval间隔
    FASTEST = 7
    SLOWEST = 0

    #对象变量
    type = -1
    internalId = 0

    #方法
    def __init__(self, type):
        self.type = type  # 外部传入参数赋值给属性type
        #print(self.type)

    def getSpeed(self): #获取当前VM的处理速度
        return VM.SPEEDS[self.type]

    def getType(self): #获取当前VM的类型
        return self.type
    @staticmethod
    def non_dominated_types(): #返回所有非支配机器类型
        rtl = []
        for i in range(len(VM.SPEEDS)):
            is_dominated = 0
            for j in range(i+1,len(VM.SPEEDS)):
                if VM.SPEEDS[j]>=VM.SPEEDS[i] and VM.UNIT_COSTS[j]<=VM.UNIT_COSTS[i]:
                    is_dominated = 1
                    break
            if is_dominated==0:
                rtl.append(i)
        return rtl

    @staticmethod
    def EffRate(y): #求机器类型y的性价比
        return VM.SPEEDS[y]/VM.UNIT_COSTS[y]

    @staticmethod
    def cmp_based_EffRate(y1,y2): #比较两个类型y1和y2,高EffRate排在前面，同EffRate则高speed排在前面
        er1 = VM.EffRate(y1)
        er2 = VM.EffRate(y2)
        if math.isclose(er1,er2):
                return int(VM.SPEEDS[y1]<VM.SPEEDS[y2])*2-1
        else:
            return int(er1 < er2)*2-1


    @staticmethod
    def avg_speed(): #求所有类型的平均处理速度
        return sum(VM.SPEEDS) / len(VM.SPEEDS)

