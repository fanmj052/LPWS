import math
import random
from functools import cmp_to_key

from Setting.VM import VM


class Solution:
    # 问题
    wf = None  # 求解的工作流

    # 策略变量
    is_prefer_low_cost_and_fastest = False  # True or False

    # 决策变量
    UseVMs = None  # 租用的机器
    Vm_of_task = None  # 每个任务使用的机器
    ST = None  # 各个任务开始时间

    # 评价指标
    cost = None  # 总租金
    makespan = None  # 完工时间
    # feasiblity = None #可行性

    # 辅助变量
    ET = None  # 各个任务处理时间
    FT = None  # 各个任务结束时间
    # task_priority = []  # 任务优先级,由sheduler设置
    Tasks_of_vm = None  # 各个机器处理的tasks,按照开始时间升序排序
    tiny_num = 1E-8
    cmp_key = None
    # 记录变量
    leased_VM_types = None  # PlanB辅助变量,租用机器类型
    available_VM_hour = None  # PlanB辅助变量,各机器类型租用时段
    task_priority_list = None  # PlanB辅助变量,构建解用的任务优先级
    used_FES = None  # PlanB辅助变量, 记录初始化器输出该解时使用的评价次数
    runTime = None  # 记录调度时间，用于并行
    # 调试变量

    is_print_information = False  # True or False

    def __init__(self, wf):
        self.wf = wf

    # def set_task_priority(self, priority): #设置任务优先级
    #    self.task_priority = list(priority)
    #    return

    def set_cmp_key(self, keys):
        self.cmp_key = list(keys)

    def sort_tasks_based_topo_and_key(self, priority):  # 在任务依赖关系的情况下，根据任务优先级priority降序排序所有任务
        task_list = []
        # 自entry_task开始，遍历整个DAG
        remaining_in_edge_num = [0 for i in range(self.wf.task_num)]  # 每个节点剩余入边
        stack = [0 for i in range(self.wf.task_num + 1)]  # 栈,存放剩余出边为0的任务,stack[0]存储栈中任务数
        for i in range(self.wf.task_num):
            remaining_in_edge_num[i] = len(self.wf.parents[i])  # 初始化每个节点剩余出边为子节点个数
        stack[0] = 1
        stack[1] = self.wf.entry_task  # entry_task
        while stack[0] != 0:
            # best_tid出栈
            best_tid = stack[1]
            best_index = 1
            for i in range(2, stack[0] + 1):
                tid = stack[i]
                if priority[tid] > priority[best_tid]:
                    best_tid = tid
                    best_index = i
            task_list.append(best_tid)
            stack[best_index] = stack[stack[0]]
            stack[0] = stack[0] - 1
            # g更新子任务入边个数
            for ct in self.wf.children[best_tid]:  # 遍历出栈任务tid的每一个子任务pt
                remaining_in_edge_num[ct] = remaining_in_edge_num[ct] - 1  # 子任务ct入边减1
                if remaining_in_edge_num[ct] == 0:  # 子任务ct无入边则入栈
                    stack[0] = stack[0] + 1
                    stack[stack[0]] = ct
        return task_list

    def random_DTL_task_list(self):  # 按照DTL分层结果生成一个随机的任务处理序列
        task_list = []
        for i in range(len(self.wf.DTL_layers)):
            ts = list(self.wf.DTL_layers[i])
            random.shuffle(ts)
            task_list.extend(ts)
        return task_list

    def sort_tasks_based_topo_and_roulette_rank(self, Rank):  # 在任务依赖关系的情况下，根据任务rank轮盘赌选择任务
        task_list = []
        # 自entry_task开始，遍历整个DAG
        remaining_in_edge_num = [0 for i in range(self.wf.task_num)]  # 每个节点剩余入边
        stack = [0 for i in range(self.wf.task_num + 1)]  # 栈,存放剩余出边为0的任务,stack[0]存储栈中任务数
        for i in range(self.wf.task_num):
            remaining_in_edge_num[i] = len(self.wf.parents[i])  # 初始化每个节点剩余出边为子节点个数
        stack[0] = 1  # 存储候选任务数, 自stack[1]开始罗列各个候选任务
        stack[1] = self.wf.entry_task  # entry_task
        while stack[0] != 0:
            # 求候选任务rank值之和sum_r
            sum_r = 0.0
            for i in range(1, stack[0] + 1):
                tid = stack[i]
                sum_r += Rank[tid]
            # 取随机数r,范围为0-sum_r
            r = random.random() * sum_r
            # 轮盘赌选择任务
            select_index = stack[0]  # 默认为最后一个候选任务
            for i in range(1, stack[0] + 1):
                tid = stack[i]
                r -= Rank[tid]
                if r < 0.0:
                    select_index = i
                    break
            select_tid = stack[select_index]
            # select_tid出栈
            task_list.append(select_tid)
            stack[select_index] = stack[stack[0]]
            stack[0] = stack[0] - 1
            # g更新子任务入边个数
            for ct in self.wf.children[select_tid]:  # 遍历出栈任务tid的每一个子任务pt
                remaining_in_edge_num[ct] = remaining_in_edge_num[ct] - 1  # 子任务ct入边减1
                if remaining_in_edge_num[ct] == 0:  # 子任务ct无入边则入栈
                    stack[0] = stack[0] + 1
                    stack[stack[0]] = ct
        return task_list

    def sort_tasks_based_only_key(self, priority):  # 在忽略任务依赖关系的情况下，根据任务优先级priority降序排序所有任务
        task_list = list(self.wf.pass_tasks[self.wf.exit_task])
        task_list.append(self.wf.exit_task)
        self.set_cmp_key(priority)
        task_list.sort(key=cmp_to_key(self.cmp_based_only_key))
        return task_list

    def cmp_based_only_key(self, t1, t2):  # 比较两个任务t1和t2,高key排在前面
        return int(self.cmp_key[t1] < self.cmp_key[t2]) * 2 - 1

    def clear_solution(self):  # 初始化/清空解
        self.ST = [[] for i in range(self.wf.task_num)]
        self.FT = [[] for i in range(self.wf.task_num)]
        self.ET = [[] for i in range(self.wf.task_num)]
        self.Vm_of_task = [[] for i in range(self.wf.task_num)]
        self.Tasks_of_vm = [[] for i in range(self.wf.task_num * self.wf.task_num)]  # 考虑到后续可能合并两个解的机器，此处设置任务数平方的机器容量
        self.UseVMs = []
        self.cost = 0.0
        self.makespan = float('inf')

    # self.feasiblity = False

    def set_entry_task_assignment(self):  # 设定entry_task的起止时间和分配机器

        self.ST[self.wf.entry_task] = 0.0
        self.FT[self.wf.entry_task] = 0.0
        self.ET[self.wf.entry_task] = 0.0
        self.Vm_of_task[self.wf.entry_task] = -1  # 无实际使用机器

    def set_exit_task_assignment(self):  # 设定exit_task的起止时间和分配机器
        self.ST[self.wf.exit_task] = self.max_arrive_time(self.wf.exit_task, -1)
        self.FT[self.wf.exit_task] = self.ST[self.wf.exit_task]
        self.ET[self.wf.exit_task] = 0.0
        self.Vm_of_task[self.wf.exit_task] = -1

    def build_dynamincally_satDL_minCost(self, S, D0, D, T, F,
                                         pool_size):  # 按照拓扑结构, 从父任务都完成的任务中选取一个任务执行，每次执行后，动态更新候选任务特征
        # 初始化每个任务出度以及候选机器类型
        task_num = self.wf.task_num
        remaining_in_degree = [[] for i in range(self.wf.task_num)]
        for i in range(task_num):
            remaining_in_degree[i] = len(self.wf.parents[i])
        leased_VM_types = VM.non_dominated_types()  # 获取所有非支配机器类型
        leased_VM_types.sort(key=cmp_to_key(VM.cmp_based_EffRate))  # 根据EffRate对机器类型排序,高EffRate排在前,同EffRate则高speed排在前
        print("deadline:", self.wf.deadline)
        # 开始处理任务
        activated_tasks = [self.wf.entry_task]
        #   处理entry_task
        self.remove_activated_task(activated_tasks, remaining_in_degree, 0)
        #   处理real_tasks
        N = 1  # 处理完的任务个数
        while len(activated_tasks) > 0:
            # 任务预筛选，最多保留pool_size个
            task_pool = None
            task_indexs = None
            if (len(activated_tasks) > pool_size):  # 候选任务超过pool_size个，取D0值最大的pool_size个
                # activated_tasks排序，前pool_size存放D0_s值最大的任务
                for i in range(pool_size):
                    ti = activated_tasks[i]
                    for j in range(i + 1, len(activated_tasks), 1):  # 遍历activated_tasks第i个单位之后的任务
                        tj = activated_tasks[j]
                        if D0[0][ti] < D0[0][tj]:  # 交换,保持activated_tasks[i]的D0_s比后续任务大
                            activated_tasks[i] = tj
                            activated_tasks[j] = ti
                            ti = activated_tasks[i]
                # 创建task_pool，存放activated_tasks前pool_size个单位
                task_pool = [activated_tasks[k] for k in range(pool_size)]
                task_indexs = [k for k in range(pool_size)]
            else:  # 候选任务不超过pool_size个，取全部候选任务
                # 创建task_pool，存放activated_tasks前pool_size个单位
                task_pool = list(activated_tasks)
                task_indexs = [k for k in range(len(activated_tasks))]
            # 任务选择
            select_task_index = 0
            if len(task_pool) > 1:
                # 实现RL前: 随机选
                r = random.randint(0, len(task_pool) - 1)
                select_task_index = task_indexs[r]  # 随机选一个
                # 基于RL的任务选择
                input = []
                input.append(1.0 * N / (self.wf.task_num - 2))  # 要处理的第几个任务
                for t in task_pool:
                    input.append(D0[0][t] / D0[0][self.wf.entry_task])  # D0特征
                    input.append(D[0][t] / D[0][self.wf.entry_task])  # D1特征
                    input.append(T[0][t] / T[0][self.wf.entry_task])  # T特征

                    maxD = D[0][self.wf.entry_task]
                    sd = ((maxD - D[1][t]) / maxD)
                    input.append(sd)  # deadline特征

            select_task_id = activated_tasks[select_task_index]
            print('select_task_id =', select_task_id)
            # 任务分配
            maxD = D[0][self.wf.entry_task]
            sd = ((maxD - D[1][select_task_id]) / maxD) * self.wf.deadline  # 方法1
            self.assign_VM_based_subdeadline(select_task_id, sd, leased_VM_types)
            N = N + 1
            # 更新activated_task以及remaining_in_degree
            self.remove_activated_task(activated_tasks, remaining_in_degree, select_task_index)
            # 停止条件
            if len(activated_tasks) == 1 and activated_tasks[0] == self.wf.exit_task:
                # self.set_exit_task_assignment()
                break

        # 结束
        print('end  build_dynamincally_satDL_minCost')

    def get_D(self):  # 获取DAG中每个任务开始到exit_task的距离(节点权重为任务实际处理时间,边权重为实际传输时间)
        Ds = [[] for i in range(self.wf.task_num)]  # 存储每个任务开始到exit_task的距离
        Ds[self.wf.exit_task] = 0.0  # 设置exit_task的距离为0
        Df = [[] for i in range(self.wf.task_num)]  # 存储每个任务结束到exit_task的距离
        Df[self.wf.exit_task] = 0.0  # 设置exit_task的距离为0
        tlist = list(self.wf.pass_tasks[self.wf.exit_task])
        tlist.reverse()
        for t in tlist:  # 从exit_task方向遍历每一个任务
            et = self.ET[t]  # 任务t实际处理时间
            d = 0  # 任务t结束对应的D0值
            for ct in self.wf.children[t]:  # 遍历t的所有子任务ct
                tt = 0  # t和ct之间的相同机器数据所需传输时间
                if self.Vm_of_task[t] != self.Vm_of_task[ct]:
                    tt = self.wf.TransRequireTime[t][ct]  # t和ct之间的不同机器数据所需传输时间
                d = max(d, Ds[ct] + tt)  # 保留最大值
            Ds[t] = et + d  # 得到t对应Ds值
            Df[t] = d  # 得到t对应Df值
        # print('Ds[',t,']= ',Ds[t])
        return [Ds, Df]

    def get_T(self):  # 获取DAG中每个任务开始到工作流完成的时间差
        dTs = [[] for i in range(self.wf.task_num)]  # 存储每个任务开始到工作流完成的时间差
        dTf = [[] for i in range(self.wf.task_num)]  # 存储每个任务结束到工作流完成的时间差
        ms = self.total_maskspan()
        for t in range(self.wf.task_num):
            dTs[t] = ms - self.ST[t]
            dTf[t] = ms - self.FT[t]
        return [dTs, dTf]

    def cost_opt_based_slack_time(self, task_sequence, deadline):  # 去除一个机器,依据任务的弹性时间, 给该机器处理的任务重新分配其他任务使用的机器
        if len(self.UseVMs) <= 1:  # 机器数目不足2则停止
            return None
        # 求各个任务的最晚开始时间pone_ST
        FRT = self.get_flex_time()
        pone_ST = [0] * len(task_sequence)
        for t in task_sequence:
            pone_ST[t] = self.ST[t] + FRT[t]
        # 选择一个处理任务量最小的机器vm_delete
        vm_delete = 0  # 要删除的机器编号
        process_size = [0.0] * len(self.UseVMs)
        for v in range(len(self.UseVMs)):
            for t in self.Tasks_of_vm[v]:
                process_size[v] += self.wf.task_size[t]
            if process_size[vm_delete] > process_size[v]:
                vm_delete = v
        # 每个机器的租用时长
        vms_hour = self.vms_lease_hour()
        # 确定每个机器在新解里的机器编号
        vms_new_id = [None] * len(self.UseVMs)
        vms_old_id = []
        id = 0
        for v in range(len(self.UseVMs)):
            if v != vm_delete and vms_hour[v] > 0:  # v不是被删除的机器且v的租用时段大于0
                vms_new_id[v] = id
                vms_old_id.append(v)
                id += 1
        # ---------- 开始构建新解 -------------
        S = Solution(self.wf)
        S.clear_solution()
        # 创建新机器
        for v in range(len(self.UseVMs)):
            if v != vm_delete:
                new_vm = VM(self.UseVMs[v].type)
                S.UseVMs.append(new_vm)
        # 逐个任务分配机器：按照task_sequence遍历全部任务, 重新为vm_delete处理的任务分配机器
        next_visit_task_index = [0] * len(self.UseVMs)  # next_visit_task_index[v]表示self.Tasks_of_vm[v]未被访问的机器的位置

        S.set_entry_task_assignment()  # entry_task分配虚拟机器
        for t in task_sequence:
            if t == self.wf.entry_task or t == self.wf.exit_task:
                continue
            old_vm = self.Vm_of_task[t]
            if old_vm != vm_delete:  # t使用的机器不是被删除的机器vm_delete,则继续使用该机器
                new_vid = vms_new_id[old_vm]
                # 分配机器
                t_arr = [[] for i in range(3)]  # 存储分配信息浮点数部分：起[0]止[1]时间以及新增cost[2]
                v_arr = [[] for i in range(4)]  # 存储分配信息整数部分：[0]机器编号，[1]类型，[2]新旧(是否为老机器),[3]插入位置
                v_arr[0] = new_vid
                v_arr[1] = S.UseVMs[new_vid].getType()
                v_arr[2] = 1  # 旧机器
                v_arr[3] = S.cal_ft_and_addcost_for_insert(t, new_vid, t_arr)  # 确定t_arr和v_arr[3]
                S.alloc_front_task(t, v_arr, t_arr, None)
                # 更新next_visit_task_index
                next_visit_task_index[old_vm] += 1
            else:  # t使用的机器不是被删除的机器vm_delete,重新选一个违反deadline最小的已启用机器
                # 确定每个候选机器下一个要处理的任务，存放在vm_next_tasks
                vm_next_tasks = [-1] * len(S.UseVMs)
                for new_vid in range(len(S.UseVMs)):
                    old_vid = vms_old_id[new_vid]
                    index = next_visit_task_index[old_vid]
                    if index < len(self.Tasks_of_vm[old_vid]):
                        vm_next_tasks[new_vid] = self.Tasks_of_vm[old_vid][index]
                # 选择一个候选机器
                children_vm = []  # t子任务使用的vm在新解中的机器编号
                for c in self.wf.children[t]:
                    old_vm = self.Vm_of_task[c]
                    new_vid = vms_new_id[old_vm]
                    children_vm.append(new_vid)
                new_vid = S.select_vm_min_makespan(t, pone_ST, vm_next_tasks, children_vm)
                # 分配机器
                t_arr = [[] for i in range(3)]  # 存储分配信息浮点数部分：起[0]止[1]时间以及新增cost[2]
                v_arr = [[] for i in range(4)]  # 存储分配信息整数部分：[0]机器编号，[1]类型，[2]新旧(是否为老机器),[3]插入位置
                v_arr[0] = new_vid
                v_arr[1] = S.UseVMs[new_vid].getType()
                v_arr[2] = 1  # 旧机器
                v_arr[3] = S.cal_ft_and_addcost_for_insert(t, new_vid, t_arr)  # 确定t_arr和v_arr[3]
                S.alloc_front_task(t, v_arr, t_arr, None)
        # 结束real task分配机器, 设定exit_task的起止时间和分配机器
        S.set_exit_task_assignment()
        # 计算cost
        S.cost = S.total_cost()
        # 计算makespan
        S.makespan = S.total_maskspan()
        # 检查解
        if S.is_print_information:
            print('check_is_correct:', S.check_solution())
        # 返回新的解
        return S

    def select_vm_min_makespan(self, t, pone_ST, vm_next_tasks, children_vm):  # 为任务t重新选一个机器
        new_vid = None  # 为任务t选择的机器
        best_max_violation = float('inf')  # 该新机器的最大pone_ST违反度
        for v in range(len(self.UseVMs)):  # 遍历每一个机器v
            max_violation = float('-inf')  # 存储t使用机器v造成的最大pone_ST违反度
            # 遍历t所有子任务在t使用机器v后的pone_ST违反度
            t_at = self.max_arrive_time(t, v)  # t使用机器v后,所有父任务数据的到达时间
            if len(self.Tasks_of_vm[v]) > 0:
                t_v_now = self.Tasks_of_vm[v][len(self.Tasks_of_vm[v]) - 1]  # 机器v处理的最后一个任务
                t_st = max(self.FT[t_v_now], t_at)  # 任务t使用v的开始时间,t不是v第一个处理的任务
            else:
                t_st = max(VM.LAUNCH_TIME, t_at)  # 任务t使用v的开始时间,t是v第一个处理的任务
            t_ft = t_st + self.wf.task_size[t] / self.UseVMs[v].getSpeed()  # 任务t使用v的结束时间
            for i in range(len(self.wf.children[t])):  # 遍历t的每一个子任务c
                c = self.wf.children[t][i]
                c_st = t_ft  # t使用机器v后,任务c的最早开始时间
                if children_vm[i] is None or children_vm[i] != v:  # 不同机器则传输时间
                    c_st += self.wf.TransRequireTime[t][c]
                violation = c_st - pone_ST[c]  # t使用机器v造成c的pone_ST违反度
                max_violation = max(violation, max_violation)
            # 遍历v计划处理的下一任务在t使用机器v后的pone_ST违反度
            t_v_next = vm_next_tasks[v]  # 机器v要处理的下一个任务
            if t_v_next != -1 and self.wf.is_child[t][t_v_next] == False:  # t_v_next存在且不是t的子任务
                tv_min_st = t_ft  # t比t_v_next更早使用机器v后，t_v_next的最早开始时间
                violation = tv_min_st - pone_ST[t_v_next]  # t使用机器v造成t_v_next的pone_ST违反度
                max_violation = max(violation, max_violation)
            # 比较更新,保留max_violation最小的机器
            if max_violation < best_max_violation:
                new_vid = v
                best_max_violation = max_violation
        return new_vid

    def makespan_opt_based_slack_time(self):  # 依据任务的弹性时间,优化整个workflow的makespan,返回新的解S
        FRT = self.get_flex_time()
        # 求各个任务的弹性时间rank值(弹性时间越小rank值越大)
        sort_task_list = self.sort_tasks_based_only_key(FRT)  # 按照弹性时间降序排序
        slt_rank = [0] * self.wf.task_num
        for i in range(1, len(sort_task_list), 1):
            t = sort_task_list[i]  # 当前任务
            t0 = sort_task_list[i - 1]  # 前一个任务
            if abs(FRT[t] - FRT[t0]) < self.tiny_num:  # 当前任务和上一个任务FRT值相同
                slt_rank[t] = slt_rank[t0]
            else:
                slt_rank[t] = slt_rank[t0] + 1
        # 求各个任务可达任务的slt_rank值之和,存在sum_slt_rank中
        sum_slt_rank = [0] * self.wf.task_num
        for t in sort_task_list:
            connected_tasks = self.wf.pass_tasks[t] + self.wf.arrive_tasks[t]  # t所有联通任务
            for ct in connected_tasks:
                sum_slt_rank[t] += slt_rank[ct]
        # 按照FRT、sum_slt_rank、task_size三个指标排序
        ssr_max = max(sum_slt_rank)  # 最大sum_slt_rank值
        ts_max = max(self.wf.task_size)  # 最大task_size
        sort_keys = [0] * self.wf.task_num  # 存放排序的key值
        for t in sort_task_list:  # 计算所有任务排序key值
            sort_keys[t] += slt_rank[t] * (ssr_max + 1)  # FRT的rank值放大(ssr_max+1)倍,使得不同数的差值最小为ssr_max+1
            sort_keys[t] += sum_slt_rank[t]  # sum_slt_rank值(不同数的差值最小为1,最大为ssr_max)
            sort_keys[t] += self.wf.task_size[t] / ts_max / 10.0  # task_size映射到0-0.1(不同数的差值最大为0.1)
        sort_task_list = self.sort_tasks_based_only_key(sort_keys)  # 基于sort_keys任务重新排序
        '''
		print('--------------------------------')
		for t in sort_task_list:
			#print('t', t, ' slack time:', FRT[t], '  slt_rank=', slt_rank[t], '  sum_slt_rank=', sum_slt_rank[t])
			print('t', t, ':', FRT[t],'   ', sum_slt_rank[t],'   ',self.wf.task_size[t],'  |  ',sort_keys[t])
		'''
        # 执行关键任务更换机器工作
        for i in range(len(sort_task_list)):  # 按照排序结果正向遍历每一个关键任务
            tc = sort_task_list[i]  # 关键任务tc
            if tc == self.wf.entry_task or tc == self.wf.exit_task:  # tc为虚拟任务则跳到下一个任务
                continue
            if FRT[tc] > self.tiny_num:  # 遍历到非关键任务则停止
                break
            for j in range(len(sort_task_list) - 1, -1, -1):  # 按照排序结果反向遍历每一个非关键任务
                tu = sort_task_list[j]  # 关键任务tu
                if FRT[tu] < self.tiny_num:  # 遍历到关键任务则停止
                    break
                # 确定tc能否改用tu的机器，并挪到tu前面
                if self.wf.can_arrive[tc][tu] or self.wf.can_arrive[tu][tc]:  # 不允许tu tc联通(联通则无法调换顺序)
                    continue
                #	1. 求出ut可腾出的空闲时段
                # print(tc,tu)
                uvm = self.Vm_of_task[tu]
                s1 = self.prior_task_ft(tu, tc)  # tc使用tu的机器的最早开始时间
                s2 = self.ST[tu] + FRT[tu]  # tu可推迟的最大开始时间
                max_at = self.max_arrive_time(tc, uvm)  # 计算tc使用机器uvm后,所有父任务结果的到达时间max_at
                min_st = max_at  # tc最早接收完所有父任务数据的时间
                max_ft = self.min_output_time(tc, uvm, FRT)  # tc使用uvm需要开始给子任务发送数据的最晚时间，也就是最晚结束时间
                tc_new_st = max(min_st, s1)  # tc新的开始时间
                tc_new_max_ft = min(max_ft, s2)  # tc新的最大结束时间
                #	计算tc是否可移植到时段[tc_new_st,tc_new_max_ft]
                max_et = tc_new_max_ft - tc_new_st  # tc在uvm上处理的可用运行时间
                need_et = self.wf.task_size[tc] / self.UseVMs[uvm].getSpeed()  # tc在uvm上处理需要的运行时间
                if need_et < max_et + self.tiny_num:  # 移植时段可以处理tc
                    # 更新Tasks_of_vm
                    crank = self.execute_rank_on_its_vm(tc)
                    cvm = self.Vm_of_task[tc]
                    self.Tasks_of_vm[cvm].pop(crank)
                    urank = self.execute_rank_on_its_vm(tu)
                    uvm = self.Vm_of_task[tu]
                    self.Tasks_of_vm[uvm].insert(urank, tc)
                    # 更新Vm_of_task
                    self.Vm_of_task[tc] = uvm
                    # 创建新解 build_based_assigned_VM
                    task_mapped_VM = list(self.Vm_of_task)  # 拷贝task_mapped_VM
                    VMs_type = [-1] * len(self.UseVMs)  # 拷贝使用机器类型
                    # 每个任务在处理该任务的机器上的处理次序
                    process_order = [1] * len(sort_task_list)
                    for i in range(len(self.UseVMs)):
                        VMs_type[i] = self.UseVMs[i].type
                        for j in range(len(self.Tasks_of_vm[i])):
                            t = self.Tasks_of_vm[i][j]
                            process_order[t] = -j
                    new_task_list = self.sort_tasks_based_topo_and_key(process_order)  # 新的任务处理顺序,每个机器上的任务按照原次序排序
                    S = Solution(self.wf)
                    S.build_based_assigned_VM(new_task_list, task_mapped_VM, VMs_type, is_insert=True)  # 重新构建解
                    # 还原当前解
                    self.Vm_of_task[tc] = cvm
                    self.Tasks_of_vm[uvm].pop(urank)
                    self.Tasks_of_vm[cvm].insert(crank, tc)
                    return S  # 成功发现makepan更低的解S
        return None  # 未发现makepan更低的解

    def min_output_time(self, ti, vj, FRT):  # 计算任务ti在使用机器vj的情况下,任务ti的应该开始传输给各个子任务数据的最小时间min_ot
        min_ot = float('inf')  # 返回值
        for ct in self.wf.children[ti]:  # 遍历ti的全部子任务ct
            ot = self.ST[ct] + FRT[ct]  # 最晚开始时间
            if self.Vm_of_task[ct] != vj:  # 异构机器则考虑传输时间
                ot -= self.wf.TransRequireTime[ti][ct]  # 对ct的最晚传输时间
            min_ot = min(min_ot, ot)  # 去全部子任务的最小值
        return min_ot

    def execute_rank_on_its_vm(self, t):  # 计算任务t在其机器上是第几个被执行的任务
        vm = self.Vm_of_task[t]
        return self.Tasks_of_vm[vm].index(t)

    def prior_task_ft(self, ut, kt):  # 在相同机器上ut上一个任务的结束时间,ut为首任务则返回开机时间
        urank = self.execute_rank_on_its_vm(ut)
        uvm = self.Vm_of_task[ut]
        if urank == 0:  # 如果ut是在uvm上第一个被处理的任务
            bt = self.vm_boot_time(uvm)  # 开机时间
            dt = self.vm_shutdown_time(uvm)
            return dt - self.ceil_front_time(dt - bt) + self.wf.max_input_time[kt]
        else:
            prior_task = self.Tasks_of_vm[uvm][urank - 1]
            return self.FT[prior_task]

    def get_flex_time(self):  # 获得每个任务的弹性时间(也称为flex_time,slack_time)
        FRT = [[] for i in range(self.wf.task_num)]  # 存储每个任务的弹性时间
        max_bt = 0.0
        if self.wf.deadline == None:
            max_bt = self.makespan
        else:
            max_bt = self.wf.deadline
        boot_time = [max_bt for i in range(len(self.UseVMs))]  # 记录反向调度每个机器当前开机时间
        task_list = self.sort_tasks_based_only_key(self.FT)  # 任务按照FT由大到小排序
        st = [[] for i in range(self.wf.task_num)]  # 反向调度任务开始时间
        ft = [[] for i in range(self.wf.task_num)]  # 反向调度任务结束时间
        # 遍历所有task,设置反向调度起止时间
        #   设置exit_task
        st[self.wf.exit_task] = max_bt
        ft[self.wf.exit_task] = max_bt
        FRT[self.wf.exit_task] = st[self.wf.exit_task] - self.ST[self.wf.exit_task]
        #   设置其他任务
        for t in task_list:
            if t == self.wf.exit_task:
                continue
            vm = self.Vm_of_task[t]
            min_ot = float('inf')  # 反向分配机器时,计算在使用机器vm的情况下,任务t的所有子任务结果要求t最早开始传输数据时间
            for tc in self.wf.children[t]:
                output_time = st[tc]
                if self.Vm_of_task[tc] != vm:
                    output_time = output_time - self.wf.TransRequireTime[t][tc]
                min_ot = min(output_time, min_ot)
            # 计算反向分配机器的结束时间,开始时间
            ft[t] = min(min_ot, boot_time[vm])
            st[t] = ft[t] - self.ET[t]
            # 更新机器开始处理首任务时间
            boot_time[vm] = st[t]
            # 计算弹性时间
            FRT[t] = st[t] - self.ST[t]
        # 结束任务遍历,返回FRT
        return FRT

    # print('end func get_flex_time')

    def remove_activated_task(self, activated_tasks, remaining_in_degree, index):
        dt = activated_tasks[index]
        activated_tasks.__delitem__(index)
        # print()
        # print('remove ', dt)
        for ct in self.wf.children[dt]:
            remaining_in_degree[ct] = remaining_in_degree[ct] - 1
            if remaining_in_degree[ct] == 0:
                activated_tasks.append(ct)
            # print('add ', ct)

    def build_satDL_minCost(self, sorted_task_list, Ds,
                            Df):  # 每个任务依次按照sorted_task_list的顺序,在满足sub-deadline的约束下选择最小cost的任务
        # 初始化
        leased_VM_types = VM.non_dominated_types()  # 获取所有非支配机器类型
        leased_VM_types.sort(key=cmp_to_key(VM.cmp_based_EffRate))  # 根据EffRate对机器类型排序,高EffRate排在前,同EffRate则高speed排在前
        # print("deadline:",self.wf.deadline)
        self.clear_solution()
        self.set_entry_task_assignment()
        # 给所有real task分配机器
        max_D = Ds[self.wf.entry_task]
        for tid in sorted_task_list:
            if tid == self.wf.entry_task or tid == self.wf.exit_task:
                continue
            # 求tid的sub-deadline
            sd = ((max_D - Df[tid]) / max_D) * self.wf.deadline
            if self.is_print_information:
                print("sub-deadline: ", tid, sd)
            # 分配机器
            self.assign_VM_based_subdeadline(tid, sd, leased_VM_types)
        # 结束real task分配机器, 设定exit_task的起止时间和分配机器
        self.set_exit_task_assignment()
        # 计算cost
        self.cost = self.total_cost()
        # 计算makespan
        self.makespan = self.total_maskspan()
        # 检查解
        if self.is_print_information:
            print('check_is_correct:', self.check_solution())

    # print("end build_satDL_minCost")

    def select_VM_based_subdeadline(self, tid, sd, leased_VM_types):  # 基于deadline选择VM
        # 选择机器
        #   初始化最快机器信息
        fastest_tarr = None  # 存放最快机器的起止时间以及新增cost
        fastest_varr = None  # 存放最快机器的机器编号，类型，新旧(是否为老机器),插入位置
        #   初始化满足sd且cost最低机器信息
        pref_tarr = None  # 存放偏好(满足sd且cost最低)机器的起止时间以及新增cost
        pref_varr = None  # 存放偏好机器的机器编号，类型，新旧(是否为老机器),插入位置
        #   遍历所有旧机器
        for vj in range(len(self.UseVMs)):
            t_arr = [[] for i in range(3)]  # 起[0]止[1]时间以及新增cost[2]
            v_arr = [vj, self.UseVMs[vj].getType(), 1,
                     self.cal_ft_and_addcost_for_insert(tid, vj, t_arr)]  # [0]机器编号，[1]类型，[2]新旧(是否为老机器),[3]插入位置
            # 更新fastest_tarr, pref_tarr
            if t_arr != None:
                if fastest_tarr == None or t_arr[1] < fastest_tarr[1] - self.tiny_num:
                    fastest_varr = v_arr
                    fastest_tarr = t_arr
                # 更新pref_varr
                if t_arr[1] < sd + self.tiny_num:
                    if pref_tarr == None or t_arr[2] < pref_tarr[2] - self.tiny_num:  # cost更低
                        pref_varr = v_arr
                        pref_tarr = t_arr
                    elif self.is_prefer_low_cost_and_fastest and t_arr[2] < pref_tarr[2] + self.tiny_num and t_arr[1] < \
                            pref_tarr[1] - self.tiny_num:  # cost相等但是ft更小
                        # 20231121新增
                        pref_varr = v_arr
                        pref_tarr = t_arr
        #   遍历所有新机器
        max_at = self.max_arrive_time(tid, -1)
        for vmtype in leased_VM_types:
            et = self.wf.task_size[tid] / VM.SPEEDS[vmtype]
            # 生成t_arr
            t_arr = [[] for i in range(3)]  # 起[0]止[1]时间以及新增cost[2]
            t_arr[0] = max_at
            t_arr[1] = max_at + et
            hour = self.ceil_front_time(
                et + VM.LAUNCH_TIME + self.wf.max_input_time[tid] + self.wf.max_output_time[tid]) / VM.INTERVAL
            t_arr[2] = VM.UNIT_COSTS[vmtype] * hour
            # 生成v_arr
            v_arr = [-1, vmtype, 0, 0]  # [0]机器编号，[1]类型，[2]新旧(是否为老机器),[3]插入位置
            # 更新fastest_tarr, pref_tarr
            if t_arr != None:
                if fastest_tarr == None or t_arr[1] < fastest_tarr[1] - self.tiny_num:
                    fastest_varr = v_arr
                    fastest_tarr = t_arr
                # 更新pref_varr
                if t_arr[1] < sd + self.tiny_num:
                    if pref_tarr == None or t_arr[2] < pref_tarr[2] - self.tiny_num:  # cost更低
                        pref_varr = v_arr
                        pref_tarr = t_arr
                    elif self.is_prefer_low_cost_and_fastest and t_arr[2] < pref_tarr[2] + self.tiny_num and t_arr[1] < \
                            pref_tarr[1] - self.tiny_num:  # cost相等但是ft更小
                        # 20231121新增
                        pref_varr = v_arr
                        pref_tarr = t_arr

        #   选择机器
        select_vm_infomation = [[], []]
        if pref_tarr == None:  # 无满足subdeadline机器，选择最快机器
            select_vm_infomation[0] = fastest_varr
            select_vm_infomation[1] = fastest_tarr
        else:  # 有满足subdeadline机器，选择cost最低机器
            select_vm_infomation[0] = pref_varr
            select_vm_infomation[1] = pref_tarr
        return select_vm_infomation

    def assign_VM_based_subdeadline(self, tid, sd, leased_VM_types):
        # 选择机器
        select_vm_infomation = self.select_VM_based_subdeadline(tid, sd, leased_VM_types)
        # 分配
        self.alloc_front_task(tid, select_vm_infomation[0], select_vm_infomation[1], None)

    def build_weight_sum(self, sorted_task_list, makespan_weight,
                         Z):  # 加权和选择机器, Z represent the reference values to normalize makespan and cost
        # 清空解
        self.clear_solution()
        # 初始化机器选择变量
        cur_ms = 0.0  # 当前不完整解的完工时间
        cur_cost = 0.0  # 当前不完整解的cost值
        # entry_task分配虚拟机器
        self.set_entry_task_assignment()
        # 给所有real task分配机器
        for tid in sorted_task_list:
            best_score = float('inf')  # 最优机器打分值
            best_varr = None  # 最优机器分配该任务的信息,起[0]止[1]时间以及新增cost[2]
            best_tarr = None  # 最有机器信息,[0]机器编号，[1]类型，[2]新旧(是否为老机器),[3]插入位置
            if tid == self.wf.entry_task or tid == self.wf.exit_task:  # 跳过虚拟任务
                continue
            # 遍历所有旧机器
            for vj in range(len(self.UseVMs)):
                # 计算分配信息t_arr,v_arr
                t_arr = [[] for i in range(3)]  # 起[0]止[1]时间以及新增cost[2]
                v_arr = [[] for i in range(4)]  # [0]机器编号，[1]类型，[2]新旧(是否为老机器),[3]插入位置
                v_arr[0] = vj
                v_arr[1] = self.UseVMs[vj].getType()
                v_arr[2] = 1
                v_arr[3] = self.cal_ft_and_addcost_for_insert(tid, vj, t_arr)
                # 计算使用该机器后新的makespan以及cost
                new_ms = max(cur_ms, t_arr[1])
                new_cost = cur_cost + t_arr[2]
                score = makespan_weight * (new_ms / Z[0]) + (1 - makespan_weight) * (new_cost / Z[1])  # MOELS eq.(11)
                # 更新best_varr, best_tarr
                if t_arr != None and score < best_score:
                    best_score = score
                    best_varr = v_arr
                    best_tarr = t_arr
            # 遍历所有新机器
            max_at = self.max_arrive_time(tid, -1)
            for vmtype in range(len(VM.SPEEDS)):
                et = self.wf.task_size[tid] / VM.SPEEDS[vmtype]
                # 生成t_arr
                t_arr = [[] for i in range(3)]  # 起[0]止[1]时间以及新增cost[2]
                t_arr[0] = max_at
                t_arr[1] = max_at + et
                hour = self.ceil_front_time(
                    et + VM.LAUNCH_TIME + self.wf.max_input_time[tid] + self.wf.max_output_time[tid]) / VM.INTERVAL
                t_arr[2] = VM.UNIT_COSTS[vmtype] * hour
                # 生成v_arr
                v_arr = [[] for i in range(4)]  # [0]机器编号，[1]类型，[2]新旧(是否为老机器),[3]插入位置
                v_arr[0] = -1
                v_arr[1] = vmtype
                v_arr[2] = 0
                v_arr[3] = 0
                # 计算使用该机器后新的makespan以及cost
                new_ms = max(cur_ms, t_arr[1])
                new_cost = cur_cost + t_arr[2]
                score = makespan_weight * (new_ms / Z[0]) + (1 - makespan_weight) * (new_cost / Z[1])  # MOELS eq.(11)
                # 更新best_varr, best_tarr
                if t_arr != None and score < best_score:
                    best_score = score
                    best_varr = v_arr
                    best_tarr = t_arr
            # 结束新旧机器遍历，选择score最高机器，更新cur_ms和cur_cost
            cur_ms = max(cur_ms, best_tarr[1])
            cur_cost = cur_cost + best_tarr[2]
            self.alloc_front_task(tid, best_varr, best_tarr, None)
        # 结束real task分配机器, 设定exit_task的起止时间和分配机器
        self.set_exit_task_assignment()
        # 计算cost
        self.cost = self.total_cost()
        # 计算makespan
        self.makespan = self.total_maskspan()
        # 检查解
        if self.is_print_information:
            print('check_is_correct:', self.check_solution())

    # end func build_weight_sum

    def build_based_assigned_VM(self, sorted_task_list, task_mapped_VM,
                                VMs_type, is_insert=False):  # 给定任务处理顺序、分配的机器,以及各个机器的类型，构建一个完整的调度解
        # 参数:
        # sorted_task_list[i]: 第i个要处理的任务(生成sorted_task_list的方法可参照sort_tasks_based_topo_and_key函数)
        # task_mapped_VM[i]: 给i任务指定的机器的编号
        # VMs_type[v]: 机器v的类型
        # 清空解
        self.clear_solution()
        # 创建全部机器
        for v in range(len(VMs_type)):
            new_vm = VM(VMs_type[v])
            self.UseVMs.append(new_vm)
        # entry_task分配虚拟机器
        self.set_entry_task_assignment()
        # 给所有real task分配机器
        for tid in sorted_task_list:
            if tid == self.wf.entry_task or tid == self.wf.exit_task:  # 虚拟任务则跳过
                continue
            vj = task_mapped_VM[tid]  # tid任务选择的机器的编号
            # 确定机器
            t_arr = None  # 存放最快机器的起止时间以及新增cost
            v_arr = None  # 存放最快机器的机器编号，类型，新旧(是否为老机器),插入位置
            if vj is not None:  # 已指定机器
                t_arr = [[] for i in range(3)]  # 存储分配信息浮点数部分：起[0]止[1]时间以及新增cost[2]
                v_arr = [[] for i in range(4)]  # 存储分配信息整数部分：[0]机器编号，[1]类型，[2]新旧(是否为老机器),[3]插入位置
                v_arr[0] = vj
                v_arr[1] = self.UseVMs[vj].getType()
                v_arr[2] = 1  # 旧机器
                if is_insert: #插入式决定开始时间
                    v_arr[3] = self.cal_ft_and_addcost_for_insert(tid, vj, t_arr)  # 确定t_arr和v_arr[3]
                else: #末尾式决定开始时间
                    v_arr[3] = self.cal_ft_and_addcost_for_last_processing(tid, vj, t_arr)  # 确定t_arr和v_arr[3]
            else:  # 未指定机器, HEFT选择一个最快完成的机器
                #print('    出现未指定机器情况！！')
                for v in range(len(self.UseVMs)):  # 遍历每一个机器v
                    tr = [[] for i in range(3)]  # 起[0]止[1]时间以及新增cost[2]
                    vr = [[] for i in range(4)]  # [0]机器编号，[1]类型，[2]新旧(是否为老机器),[3]插入位置
                    vr[0] = v
                    vr[1] = self.UseVMs[v].getType()
                    vr[2] = 1
                    if is_insert: #插入式决定开始时间
                        vr[3] = self.cal_ft_and_addcost_for_insert(tid, v, tr)
                    else: #末尾式决定开始时间
                        vr[3] = self.cal_ft_and_addcost_for_last_processing(tid, v, tr)
                    if t_arr == None or tr[1] < t_arr[1] - self.tiny_num:
                        v_arr = vr
                        t_arr = tr
            # 分配机器
            self.alloc_front_task(tid, v_arr, t_arr, None)
        # 结束real task分配机器, 设定exit_task的起止时间和分配机器
        self.set_exit_task_assignment()
        # 计算cost
        self.cost = self.total_cost()
        # 计算makespan
        self.makespan = self.total_maskspan()
        # 检查解
        if self.is_print_information:
            print('check_is_correct:', self.check_solution())

    def build_HEFT(self, leased_VM_types, available_VM_hour, sorted_task_list):  # GPP-HEFT构建解的方法
        self.leased_VM_types = list(leased_VM_types)  # PlanB存储
        self.available_VM_hour = list(available_VM_hour)  # PlanB存储
        if self.is_print_information:
            print("leased_VM_types:", leased_VM_types)
            print("available_VM_hour:", available_VM_hour)
        self.clear_solution()
        self.set_entry_task_assignment()
        # 给所有real task分配机器
        for tid in sorted_task_list:
            if tid == self.wf.entry_task or tid == self.wf.exit_task:
                continue
            # 初始化最快机器信息
            fastest_tarr = None  # 存放最快机器的起止时间以及新增cost
            fastest_varr = None  # 存放最快机器的机器编号，类型，新旧(是否为老机器),插入位置
            # 初始化最快免费机器信息
            free_tarr = None  # 存放最快免费机器的起止时间以及新增cost
            free_varr = None  # 存放最快免费机器的机器编号，类型，新旧(是否为老机器),插入位置
            # 遍历所有旧机器
            for vj in range(len(self.UseVMs)):
                t_arr = [[] for i in range(3)]  # 起[0]止[1]时间以及新增cost[2]
                v_arr = [[] for i in range(4)]  # [0]机器编号，[1]类型，[2]新旧(是否为老机器),[3]插入位置
                v_arr[0] = vj
                v_arr[1] = self.UseVMs[vj].getType()
                v_arr[2] = 1
                v_arr[3] = self.cal_ft_and_addcost_for_insert(tid, vj, t_arr)
                # 更新fastest_tarr, free_tarr
                if t_arr != None:
                    if fastest_tarr == None or t_arr[1] < fastest_tarr[1]:
                        fastest_varr = v_arr
                        fastest_tarr = t_arr
                    # 更新free_tarr
                    if t_arr[2] < self.tiny_num and (free_tarr == None or t_arr[1] < free_tarr[1]):
                        free_varr = v_arr
                        free_tarr = t_arr
            # 遍历所有新机器
            max_at = self.max_arrive_time(tid, -1)
            for vmtype in leased_VM_types:
                if available_VM_hour[vmtype] <= 0:
                    continue
                et = self.wf.task_size[tid] / VM.SPEEDS[vmtype]
                # 生成t_arr
                t_arr = [[] for i in range(3)]  # 起[0]止[1]时间以及新增cost[2]
                t_arr[0] = max_at
                t_arr[1] = max_at + et
                hour = self.ceil_front_time(
                    et + VM.LAUNCH_TIME + self.wf.max_input_time[tid] + self.wf.max_output_time[tid]) / VM.INTERVAL
                t_arr[2] = VM.UNIT_COSTS[vmtype] * hour
                # 生成v_arr
                v_arr = [[] for i in range(4)]  # [0]机器编号，[1]类型，[2]新旧(是否为老机器),[3]插入位置
                v_arr[0] = -1
                v_arr[1] = vmtype
                v_arr[2] = 0
                v_arr[3] = 0
                # 更新fastest_tarr
                if fastest_tarr == None or t_arr[1] < fastest_tarr[1]:
                    fastest_varr = v_arr
                    fastest_tarr = t_arr
            # 结束新旧机器遍历，选择机器
            need_lease_hour = self.task_lease_hour(fastest_varr, fastest_tarr)
            fastest_vm_type = fastest_varr[1]
            if free_tarr == None or need_lease_hour <= available_VM_hour[fastest_vm_type]:
                self.alloc_front_task(tid, fastest_varr, fastest_tarr, available_VM_hour)
            else:
                self.alloc_front_task(tid, free_varr, free_tarr, available_VM_hour)
        # 结束real task分配机器, 设定exit_task的起止时间和分配机器
        self.set_exit_task_assignment()
        # 计算cost
        self.cost = self.total_cost()
        # 计算makespan
        self.makespan = self.total_maskspan()
        # 检查解
        if self.is_print_information:
            print('check_is_correct:', self.check_solution())

    # print('end build_HEFT')

    def is_satisfied_budget_constraint(self, budget):
        return self.total_cost() <= budget + self.tiny_num

    def is_satisfied_deadline_constraint(self, deadline):
        return self.total_maskspan() <= deadline + self.tiny_num

    def fitness_for_budget_constraints(self):
        if self.cost > self.wf.budget + 1E-8:
            Fq = (self.cost - self.wf.budget) / self.wf.budget
            beta = self.wf.cheap_schedule_makespan - self.wf.fast_schedule_makespan
            return self.makespan + beta * Fq
        else:
            return self.makespan

    def check_solution(self):  # 检查当前解是否满足基础约束，即不违反任务依赖关系，不存在VM冲突
        for tid in range(self.wf.task_num):
            st = self.ST[tid]
            ft = self.FT[tid]
            et = self.ET[tid]
            vm = self.Vm_of_task[tid]
            vm_rank = self.execute_rank_on_its_vm(tid)
            # 检查et
            if abs(self.wf.task_size[tid] / self.UseVMs[vm].getSpeed() - et) > self.tiny_num:
                print("task", tid, "et error, task_size/vm_speed ~= et ")
                print('task_size:', self.wf.task_size[tid])
                print('vm_speed:', self.UseVMs[vm].getSpeed())
                print('et:', et)
                return False
            if math.isclose(ft, st + et) == False:
                print("task", tid, "et error, st + et ~= ft")
                return False
            # st大于等于所有父任务的ft+传输时间
            for pt in self.wf.parents[tid]:
                arrive_time = self.FT[pt]
                if self.Vm_of_task[pt] != self.Vm_of_task[tid]:
                    arrive_time = arrive_time + self.wf.TransRequireTime[pt][tid]
                    if arrive_time > st + self.tiny_num:
                        print("task", pt, "-> task", tid, "error")
                        return False
            # ft小于等于所有子任务的st-传输时间
            for ct in self.wf.children[tid]:
                output_time = self.ST[ct]
                if self.Vm_of_task[tid] != self.Vm_of_task[ct]:
                    output_time = output_time - self.wf.TransRequireTime[tid][ct]
                    if output_time < ft - self.tiny_num:
                        print("task", tid, "-> task", ct, "error")
                        return False
            if (tid != self.wf.entry_task and tid != self.wf.exit_task):
                # st大于等于同一机器上上一个执行任务的ft
                if vm_rank > 0:
                    last_task = self.Tasks_of_vm[vm][vm_rank - 1]
                    if self.FT[last_task] > st + self.tiny_num:
                        print("vm ", vm, " :task ", last_task, " -> task ", tid, " error")
                        return False
                # ft小于等于同一机器下一个执行任务的st
                if vm_rank < len(self.Tasks_of_vm[vm]) - 1:
                    next_task = self.Tasks_of_vm[vm][vm_rank + 1]
                    if (self.ST[next_task] < ft - self.tiny_num):
                        print("vm" + vm + ":task " + tid + "-> task" + next_task + "error")
                        return False
        return True

    def execute_rank_on_its_vm(self, tid):  # 任务tid在其机器上第几个被处理
        if (tid == self.wf.entry_task or tid == self.wf.exit_task):
            return -1
        vm = self.Vm_of_task[tid]
        return self.Tasks_of_vm[vm].index(tid)

    def total_cost(self):  # 计算总的cost值(已考虑空机器的情况)
        cost = 0.0
        for v in range(len(self.UseVMs)):
            if len(self.Tasks_of_vm[v]) != 0:  # 如果该机器处理任务数不为0
                vm_type = self.UseVMs[v].getType()
                bt = self.vm_boot_time(v)
                dt = self.vm_shutdown_time(v)
                hour = self.ceil_front_time(dt - bt) / VM.INTERVAL
                c = VM.UNIT_COSTS[vm_type] * hour
                cost = cost + c
        return cost

    def vms_lease_hour(self):  # 计算每个机器的租用周期数
        vms_hour = [0.0] * len(self.UseVMs)
        for v in range(len(self.UseVMs)):
            if len(self.Tasks_of_vm[v]) != 0:  # 如果该机器处理任务数不为0
                bt = self.vm_boot_time(v)
                dt = self.vm_shutdown_time(v)
                hour = self.ceil_front_time(dt - bt) / VM.INTERVAL
                vms_hour[v] = hour
        return vms_hour

    def process_tasks_size(self, vid):  # 机器vid处理全部任务的总size
        ts = 0.0
        for t in self.Tasks_of_vm[vid]:
            ts += self.wf.task_size[t]
        return ts

    def min_process_size_VM(self):
        min_VM = -1
        min_ts = float('inf')
        for v in range(0, len(self.UseVMs)):
            ts = self.process_tasks_size(v)
            if ts < min_ts:
                min_VM = v
                min_ts = ts
        return min_VM

    def total_maskspan(self):  # 计算工作流的完工时间
        return self.FT[self.wf.exit_task]

    def is_empty_vm(self, vid):
        return len(self.Tasks_of_vm[vid]) == 0

    def merge_adjacent_lease_process(self):  # MOACS中的合并机器操作
        i = 0  # 机器编号
        while i < len(self.UseVMs):  # 遍历每一个机器i
            if self.is_empty_vm(i):  # 空机器则跳过
                i += 1
                continue
            # 遍历i之后的机器，找出在i开机前最晚shutdown的机器
            merge_vid = None  # 在i机器之前最晚shutdown的机器编号
            merge_v_sdt = -float('inf')
            bt = self.vm_boot_time(i)  # 机器i开机时间
            for j in range(i + 1, len(self.UseVMs), 1):  # 遍历i之后的机器j
                if self.is_empty_vm(j) or self.UseVMs[i].getType() != self.UseVMs[j].getType():  # 空机器或异构机器则跳过
                    continue
                sdt = self.vm_shutdown_time(j)
                if sdt < bt and sdt > merge_v_sdt:
                    merge_vid = j
                    merge_v_sdt = sdt
            # 合并机器
            if merge_vid is not None and bt - merge_v_sdt < VM.INTERVAL:  # 间隔小于一个计费周期则有意义
                for t in self.Tasks_of_vm[merge_vid]:  # 更改merge_vid处理的所有任务的机器编号为i
                    self.Vm_of_task[t] = i
                self.Tasks_of_vm[i] = self.Tasks_of_vm[merge_vid] + self.Tasks_of_vm[i]  # 合并Tasks_of_vm
                self.Tasks_of_vm[merge_vid] = []  # 清空merge_vid的处理任务列表,i不加一,重新遍历j
            else:
                i += 1
                continue
        # 结束,重新评价
        #   计算cost
        self.cost = self.total_cost()
        #   计算makespan
        self.makespan = self.total_maskspan()
        #   检查解
        if self.is_print_information:
            print('check_is_correct:', self.check_solution())

    def alloc_front_task(self, tid, v_arr, t_arr, available_VM_hour):  # 指定机器以及所有要更新的参数,给tid分配机器
        # 确定机器编号，旧机器则直接使用;新机器则创建编号，更新used_vm_num,this.VM_Array[],front_vm_list
        vm = -1
        if v_arr[2] == 1:
            vm = v_arr[0]
        else:
            vm = len(self.UseVMs)
            self.UseVMs.append(VM(v_arr[1]))
        # 更新this.Vm_of_task
        self.Vm_of_task[tid] = vm
        # 更新this.start_time,this.finish_time
        self.ST[tid] = t_arr[0]
        self.FT[tid] = t_arr[1]
        self.ET[tid] = t_arr[1] - t_arr[0]
        # 更新this.Tasks_of_vm[vm]
        self.Tasks_of_vm[vm].insert(v_arr[3], tid)
        # 更新available_VM_hour
        if (available_VM_hour != None):
            available_VM_hour[v_arr[1]] -= self.task_lease_hour(v_arr, t_arr)
        # 打印过程信息
        if self.is_print_information:
            if v_arr[2] == 1:
                print("assign old vm", vm, "(type = ", self.UseVMs[vm].getType(), ")", " to front task ", tid)
            else:
                print("assign new vm", vm, "(type = ", self.UseVMs[vm].getType(), ")", " to front task ", tid)
            print("	[", self.ST[tid], ",", self.FT[tid], "]")
            print("	tloc = ", v_arr[3])
            print("	add_cost = ", t_arr[2])
            print()

    def task_lease_hour(self, varr, tarr):  # 计算需要额外租赁的时段数目
        vm_type = varr[1]
        return (int)(tarr[2] / VM.UNIT_COSTS[vm_type] + self.tiny_num)

    def cal_ft_and_addcost_for_last_processing(self, tid, vj,
                                               t_arr):  # 计算将任务ti分配给机器vj【作为最后一个任务处理】的开始时间,完成时间以及新增cost,存放在t_arr[0]-[2],并返回在vj上插入时段的位置
        max_at = self.max_arrive_time(tid, vj)  # tid所有父任务结果的到达时间
        et = self.wf.task_size[tid] / self.UseVMs[vj].getSpeed()
        index = self.last_period_in_exit_vm(tid, vj, max_at, et, t_arr)  # 直接使用最后的时段!!!
        if index == -1:
            t_arr = None
        return index

    def cal_ft_and_addcost_for_insert(self, tid, vj,
                                      t_arr):  # 计算将任务ti分配给机器vj的开始时间,【选择一个最早的时段】,完成时间以及新增cost,存放在t_arr[0]-[2],并返回在vj上插入时段的位置
        max_at = self.max_arrive_time(tid, vj)  # tid所有父任务结果的到达时间
        et = self.wf.task_size[tid] / self.UseVMs[vj].getSpeed()
        index = self.fastest_available_period_in_exit_vm(tid, vj, max_at, float('inf'), et, t_arr)  # 寻找空白时段,计算插入位置
        if index == -1:
            t_arr = None
        return index

    def last_period_in_exit_vm(self, tid, vm, max_at, et,
                               t_arr):  # 给定机器vm,找到最后一个时段,该时段起止时间以及新增cost存放在t_arr中，是则返回空闲时段处在所处理的第几个任务之后，无可用时段则返回-1
        st = max_at
        if len(self.Tasks_of_vm[vm])>0:
            last_task = self.Tasks_of_vm[vm][len(self.Tasks_of_vm[vm]) - 1]
            st = max(self.FT[last_task],max_at)
        t_arr[0] = st  # 开始时间
        t_arr[1] = st + et  # 结束时间
        # 计算新增cost，存入t_arr[2]
        old_hour = 0
        old_bt = float('inf')
        old_dt = -float('inf')
        if len(self.Tasks_of_vm[vm]) != 0:
            old_bt = self.vm_boot_time(vm)  # 机器vm旧的开机时间
            old_dt = self.vm_shutdown_time(vm)  # 机器vm旧的关机时间
            old_hour = self.ceil_front_time(old_dt - old_bt) / VM.INTERVAL  # 机器vm旧的时段数目
        new_bt = min(old_bt, st - VM.LAUNCH_TIME - self.wf.max_input_time[tid])  # 机器vm旧的开机时间
        new_dt = max(old_dt, st + et + self.wf.max_output_time[tid])  # 机器vm新的关机时间
        new_hour = self.ceil_front_time(new_dt - new_bt) / VM.INTERVAL  # 机器vm新的时段数目
        vm_type = self.UseVMs[vm].type  # 机器vm的机器类型
        t_arr[2] = VM.UNIT_COSTS[vm_type] * (new_hour - old_hour)  # 算新增cost
        index = len(self.Tasks_of_vm[vm])  # 记录时段数
        return index  # 插入到第几个任务之前

    def fastest_available_period_in_exit_vm(self, tid, vm, min_st, max_ft, et,
                                            t_arr):  # 给定机器vm,找到在[min_st,max_ft]时段内一个长度为et的最快空闲时段,该时段起止时间以及新增cost存放在t_arr中，是则返回空闲时段处在所处理的第几个任务之后，无可用时段则返回-1
        t_arr[2] = float('inf')  # 所有方案的最小cost
        index = -1  # 返回值，空闲时段处在所处理的第几个任务之后，无空闲时段则返回-1
        period_num = len(self.Tasks_of_vm[vm]) + 1  # 空闲时段个数
        t1 = [[] for i in range(period_num)]  # 各个时段的开始时间
        t2 = [[] for i in range(period_num)]  # 各个时段的终止时间
        # 生成t1 t2
        t1[0] = 0.0
        t2[period_num - 1] = float('inf')
        i = 1  # 时段编号
        for task in self.Tasks_of_vm[vm]:
            t1[i] = self.FT[task]
            t2[i - 1] = self.ST[task]
            i = i + 1
        # 遍历各个空闲时段
        for i in range(period_num):
            if t2[i] <= min_st + self.tiny_num:
                continue
            elif t1[i] >= max_ft - self.tiny_num:
                break
            else:
                st = max(t1[i], min_st)  # 当前时段可用开始时间
                ft = min(t2[i], max_ft);  # 当前时段可用终止时间
                if ft - st >= et - self.tiny_num:  # 可用时段可行，即时长大于等于et
                    t_arr[0] = st  # 开始时间
                    t_arr[1] = st + et  # 结束时间
                    # 计算新增cost，存入t_arr[2]
                    old_hour = 0
                    old_bt = float('inf')
                    old_dt = -float('inf')
                    if len(self.Tasks_of_vm[vm]) != 0:
                        old_bt = self.vm_boot_time(vm)  # 机器vm旧的开机时间
                        old_dt = self.vm_shutdown_time(vm)  # 机器vm旧的关机时间
                        old_hour = self.ceil_front_time(old_dt - old_bt) / VM.INTERVAL  # 机器vm旧的时段数目
                    new_bt = min(old_bt, st - VM.LAUNCH_TIME - self.wf.max_input_time[tid])  # 机器vm旧的开机时间
                    new_dt = max(old_dt, st + et + self.wf.max_output_time[tid])  # 机器vm新的关机时间
                    new_hour = self.ceil_front_time(new_dt - new_bt) / VM.INTERVAL  # 机器vm新的时段数目
                    vm_type = self.UseVMs[vm].type  # 机器vm的机器类型
                    t_arr[2] = VM.UNIT_COSTS[vm_type] * (new_hour - old_hour)  # 算新增cost
                    index = i  # 记录时段数
                    return index  # 插入到第几个任务之前

    def ceil_front_time(self, time):  # 时间time对应的收费时段数
        return math.ceil(time / VM.INTERVAL) * VM.INTERVAL

    def vm_boot_time(self, vm):  # 机器开机时间
        t = self.Tasks_of_vm[vm][0]
        return self.ST[t] - VM.LAUNCH_TIME - self.wf.max_input_time[t]

    def vm_shutdown_time(self, vm):  # 机器关机时间
        t = self.Tasks_of_vm[vm][len(self.Tasks_of_vm[vm]) - 1]
        return self.FT[t] + self.wf.max_output_time[t]

    def max_arrive_time(self, ti, vj):  # 计算在使用机器vj的情况下,任务ti的所有父任务结果的到达时间
        max_at = float('-inf')
        for tp in self.wf.parents[ti]:
            # 计算tp数据到达时间arrive_time
            arrive_time = self.FT[tp]
            if self.Vm_of_task[tp] != vj:
                # print(self.wf.name,str(tp),str(ti))
                # if type(self.wf.TransRequireTime[tp][ti])==list or type(arrive_time)==list:
                #    a = 1
                arrive_time = arrive_time + self.wf.TransRequireTime[tp][ti]
            max_at = max(arrive_time, max_at)
        return max_at
