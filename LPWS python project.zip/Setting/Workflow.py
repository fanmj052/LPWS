import math

import numpy as np

from Setting.VM import VM


def tran_list_to_tuple(a):
    b = None
    if len(np.array(a).shape) == 1:
        b = tuple(tuple(y) for y in a)
    if len(np.array(a).shape) == 2:
        b = tuple(tuple(tuple(y) for y in x) for x in a)
    if len(np.array(a).shape) == 3:
        b = tuple(tuple(tuple(tuple(tuple(z) for z in y)) for y in x) for x in a)
    return b

class Workflow:
    #基本成员
    name = None #工作流名称
    deadline = None #截止时间约束值
    budget = None #cost预算值
    entry_task = -1 #入口任务
    exit_task = -1  #出口任务
    task_num = -1 #任务个数
    task_size = () #每个任务的数据量,声明为tuple(元组),数据可被查询，但不能被修改
    TransDataSize = () #每条边的传输数据量,声明为tuple(元组),数据可被查询，但不能被修改
    TransRequireTime = () #在当前网速下每条边的传输数据时间,声明为tuple(元组)
    parents = ()  # parents[i]存放任务i的所有父任务
    children = ()  # children[i]存放任务i的所有子任务
    is_child = () #is_child[i][j]表示任务j是否是任务i的子任务,声明为tuple(元组)
    can_arrive = () #can_arrive[i][j]表示任务i是否可达任务j,声明为tuple(元组)
    arrive_tasks = () #arrive_tasks[i]存放任务i可到达的所有任务（子孙任务）,声明为tuple(元组)
    pass_tasks = () #pass_tasks[i]存放任务i可经过的所有任务（祖先任务）,声明为tuple(元组)
    max_input_time = () #各个任务所有入边最大传输时间
    max_output_time = () #各个任务所有出边最大传输时间
    DTL_layers = None #自开始任务分层,DTL_layers[i]存放第i层的全部任务
    #参考指标
    fast_schedule_cost = None #估计的最快调度的cost值
    fast_schedule_makespan = None #估计的最快调度的makespan值
    cheap_schedule_cost = None #估计的最慢调度的cost值
    cheap_schedule_makespan = None #估计的最慢调度的makespan值
    #算法自定义数据
    Source = None  # MOACS调度源文件



    def __init__(self,path):
        self.read_workfolow(path)

    #设置deadline
    def set_deadline(self,dl):
        self.deadline = dl

    #设置budget
    def set_budget(self,bg):
        self.budget = bg

    def get_D0_with_diff_speed(self,tasks_speed): #获取DAG中每个任务结束到exit_task的距离(tasks_speed[t]表示第t个任务的处理速度，不忽略任何边的传输时间)
        D0_s = [[] for i in range(self.task_num)] #存储每个任务的距离
        D0_f = [[] for i in range(self.task_num)]  # 存储每个任务的距离
        D0_s[self.exit_task] = 0.0 #设置exit_task的距离为0
        D0_f[self.exit_task] = 0.0  #设置exit_task的距离为0
        tlist = list(self.pass_tasks[self.exit_task])
        tlist.reverse()
        for t in tlist: #从exit_task方向遍历每一个任务
            et = self.task_size[t]/tasks_speed[t] #任务t在avg_speed处理速度下的处理时间
            d = 0 #任务t结束对应的D0值
            for ct in self.children[t]: #遍历t的所有子任务ct
                tt = self.TransRequireTime[t][ct] #t和ct之间的数据所需传输时间
                d = max(d, D0_s[ct] + tt) #保留最大值
            D0_s[t] = et + d #得到t开始对应D0值
            D0_f[t] = d #得到t结束对应D0_f值

            #print('D0_s[',t,']= ',D0_s[t])
        return [D0_s, D0_f]

    def get_D0(self,avg_speed): #获取DAG中每个任务结束到exit_task的距离(假定机器处理速度均为avg_speed，不忽略任何边的传输时间)
        D0_s = [[] for i in range(self.task_num)] #存储每个任务的距离
        D0_f = [[] for i in range(self.task_num)]  # 存储每个任务的距离
        D0_s[self.exit_task] = 0.0 #设置exit_task的距离为0
        D0_f[self.exit_task] = 0.0  #设置exit_task的距离为0
        tlist = list(self.pass_tasks[self.exit_task])
        tlist.reverse()
        for t in tlist: #从exit_task方向遍历每一个任务
            et = self.task_size[t]/avg_speed #任务t在avg_speed处理速度下的处理时间
            d = 0 #任务t结束对应的D0值
            for ct in self.children[t]: #遍历t的所有子任务ct
                tt = self.TransRequireTime[t][ct] #t和ct之间的数据所需传输时间
                d = max(d, D0_s[ct] + tt) #保留最大值
            D0_s[t] = et + d #得到t开始对应D0值
            D0_f[t] = d #得到t结束对应D0_f值

            #print('D0_s[',t,']= ',D0_s[t])
        return [D0_s, D0_f]

    def get_Dn(self,avg_speed): #获取DAG中每个任务结束到exit_task的距离(假定机器处理速度均为avg_speed，忽略任何边的传输时间)
        Dn_s = [[] for i in range(self.task_num)] #存储每个任务的距离
        Dn_f = [[] for i in range(self.task_num)]  # 存储每个任务的距离
        Dn_s[self.exit_task] = 0.0 #设置exit_task的距离为0
        Dn_f[self.exit_task] = 0.0  #设置exit_task的距离为0
        tlist = list(self.pass_tasks[self.exit_task])
        tlist.reverse()
        for t in tlist: #从exit_task方向遍历每一个任务
            et = self.task_size[t]/avg_speed #任务t在avg_speed处理速度下的处理时间
            d = 0 #任务t结束对应的D0值
            for ct in self.children[t]: #遍历t的所有子任务ct
                d = max(d, Dn_s[ct]) #保留子任务Dn_s最大值
            Dn_s[t] = et + d #得到t开始对应D0值
            Dn_f[t] = d #得到t结束对应D0_f值

            #print('Dn_s[',t,']= ',Dn_s[t])
        return [Dn_s, Dn_f]


    #总任务量
    def total_task_size(self):
        return sum(self.task_size)
    def read_workfolow(self,path): #读取工作流
        #获取wf名
        a = path.split('\\')
        b = a[-1].split('.txt')
        self.name = b[0]
        self.Source = []
        #打开文件
        f = open(path)
        # 读取第1行,获得task个数
        line = f.readline().strip()
        list = line.split(' ')
        self.task_num = len(list)
        self.Source.append(list)

        # 读取第2行,获取task_size
        line = f.readline().strip()
        list = line.split(' ')
        for i in range(self.task_num):
            list[i] = float(list[i]) #str转为float数
        self.task_size = tuple(list)  # 将列表转为元组
        self.Source.append(list)


        # 读取第3行, 获取边的头结点
        line = f.readline().strip()
        list = line.split(' ')
        for i in range(len(list)):
            list[i] = int(list[i])  # str转为int
        heads = list
        self.Source.append(list)


        # 读取第4行, 获取边的尾结点
        line = f.readline().strip()
        list = line.split(' ')
        for i in range(len(list)):
            list[i] = int(list[i])  # str转为int
        tails = list
        self.Source.append(list)

        # 读取第5行, 获取边的权重
        line = f.readline().strip()
        list = line.split(' ')
        for i in range(len(list)):
            list[i] = float(list[i])  # str转为float数
        weights = list  # 将列表转为元组
        self.Source.append(list)


        # 读取第6行，获取FastSchedule信息
        line = f.readline().strip()
        list = line.split(' ')
        self.fast_schedule_cost = float(list[2])
        self.fast_schedule_makespan = float(list[3])
        self.Source.append(list)

        # 读取第7行，获取CheapSchedule信息
        line = f.readline().strip()
        list = line.split(' ')
        self.cheap_schedule_cost = float(list[2])
        self.cheap_schedule_makespan = float(list[3])
        self.Source.append(list)

        f.close()  # 关闭文件

        #处理边信息
        ws = [[[] for i in range(self.task_num)] for i in range(self.task_num)] #存放边权重
        tt = [[[] for i in range(self.task_num)] for i in range(self.task_num)] #存放边传输时间
        is_child = [[False for i in range(self.task_num)] for i in range(self.task_num)] #is_child[i][j]表示任务j是否为任务i的子任务
        parents = []  # 创建一个空列表,存储每一个任务的全部父任务编号
        children = [] # 创建一个空列表,存储每一个任务的全部子任务编号
        for i in range(self.task_num):  # 创建一个task_num行的列表（行）
            parents.append([])  # 初始化parents[i]为空
            children.append([])  # 初始化children[i]为空
        for i in range(len(heads)):
            h = heads[i] #头结点
            t = tails[i] #尾结点
            w = weights[i] #权值
            #print(h,t,w)
            parents[t].append(h)
            children[h].append(t)
            ws[h][t] = w
            tt[h][t] = w/VM.NETWORK_SPEED
            is_child[h][t] = True
        #   获取入口任务以及出口任务编号
        en_task_num = 0
        ex_task_num = 0
        for i in range(self.task_num):
            if len(parents[i])==0:
                self.entry_task = i
                en_task_num = en_task_num + 1
            if len(children[i])==0:
                self.exit_task = i
                ex_task_num = ex_task_num + 1
        if en_task_num != 1: #检查entry_task_num个数
            print('Workflow ERROR: entry_task_num = ' + en_task_num)
            while True:
                pass
        if ex_task_num != 1: #检查exit_task_num个数
            print('Workflow ERROR: exit_task_num = ' + ex_task_num)
            while True:
                pass
        #   去除冗余边(未实现)

        #   获得can_arrive,arrive_tasks
        can_arrive = [[False for i in range(self.task_num)] for i in range(self.task_num)] #can_arrive[i][j]:任务i是否可达任务j
        arrive_tasks = [[] for i in range(self.task_num)]  # 每个节点可达的tasks
        #       自end_task开始，遍历整个DAG
        remaining_out_edge_num = [0 for i in range(self.task_num)] #每个节点剩余出边
        stack = [0 for i in range(self.task_num+1)]  # 栈,存放剩余出边为0的任务,stack[0]存储栈中任务数
        for i in range(self.task_num):
            remaining_out_edge_num[i] = len(children[i]) #初始化每个节点剩余出边为子节点个数
        stack[0] = 1
        stack[1] = self.exit_task #exit_task入栈
        while stack[0]!=0:
            #tid出栈
            tid = stack[stack[0]]
            stack[0] = stack[0] - 1
            for pt in parents[tid]: #遍历出栈任务tid的每一个父任务pt
                remaining_out_edge_num[pt] = remaining_out_edge_num[pt] - 1 #父任务pt出边减一
                if remaining_out_edge_num[pt]==0: #父任务pt无出边则入栈
                    stack[0] = stack[0] + 1
                    stack[stack[0]] = pt
                for ct in arrive_tasks[tid]: #遍历出栈任务tid的每一个可达任务ct,将ct可达的任务录入arrive_tasks[pt]
                    if can_arrive[pt][ct]==False:
                        can_arrive[pt][ct] = True
                        arrive_tasks[pt].append(ct)
                if can_arrive[pt][tid]==False: #设置pt可达tid
                    can_arrive[pt][tid] = True
                    arrive_tasks[pt].append(tid)
        for i in range(self.task_num): #arrive_tasks转置,按照深度优先遍历顺序排列
            arrive_tasks[i].reverse()

        #   获得pass_tasks
        pass_tasks = [[] for i in range(self.task_num)]  # 每个节点经过的tasks
        for i in range(self.task_num):
            if can_arrive[self.entry_task][i]:
                pass_tasks[i].append(self.entry_task)
            for j in arrive_tasks[self.entry_task]:
                if can_arrive[j][i]:
                    pass_tasks[i].append(j)

        #建立最大输入时间
        max_input_time = [0.0 for i in range(self.task_num)]
        for t in range(self.task_num):
            for pt in parents[t]:
                max_input_time[t] = max(max_input_time[t],tt[pt][t])

        #建立最大输出时间
        max_output_time = [0.0 for i in range(self.task_num)]
        for t in range(self.task_num):
            for ct in children[t]:
                max_output_time[t] = max(max_output_time[t],tt[t][ct])

        #转换为tuple类型的成员变量
        self.TransDataSize = tuple(tuple(y) for y in ws)
        #self.TransDataSize = tran_list_to_tuple(ws)
        #self.TransDataSize = tuple(ws)  # 将列表转为元组
        self.TransRequireTime = tuple(tuple(y) for y in tt)
        self.is_child = tuple(tuple(y) for y in is_child)
        self.parents = tuple(tuple(y) for y in parents)
        self.children = tuple(tuple(y) for y in children)
        self.can_arrive = tuple(tuple(y) for y in can_arrive)
        self.arrive_tasks = tuple(tuple(y) for y in arrive_tasks)
        self.pass_tasks = tuple(tuple(y) for y in pass_tasks)
        self.max_input_time = tuple(max_input_time)
        self.max_output_time = tuple(max_output_time)
        self.DTL_layers = self.cal_DTL()
        #print("finish reading workflow")

    def cal_DTL(self):  # 分层
        layers = []
        # 自entry_task开始，遍历整个DAG
        remaining_in_edge_num = [0 for i in range(self.task_num)]  # 每个节点剩余入边
        stack = [0 for i in range(self.task_num + 1)]  # 栈,存放剩余出边为0的任务,stack[0]存储栈中任务数
        for i in range(self.task_num):
            remaining_in_edge_num[i] = len(self.parents[i])  # 初始化每个节点剩余出边为子节点个数
        stack[0] = 1
        stack[1] = self.entry_task  # entry_task
        current_level_tasks = [] #存放当前层的所有任务
        next_level_tasks = [] #存放下一层的所有任务
        while stack[0] != 0:
            # best_tid出栈
            sel_tid = stack[1]
            sel_index = 1
            current_level_tasks.append(sel_tid)
            stack[sel_index] = stack[stack[0]]
            stack[0] = stack[0] - 1
            # g更新子任务入边个数
            for ct in self.children[sel_tid]:  # 遍历出栈任务tid的每一个子任务pt
                remaining_in_edge_num[ct] = remaining_in_edge_num[ct] - 1  # 子任务ct入边减1
                if remaining_in_edge_num[ct] == 0:  # 子任务ct无入边则记录到下一层中
                    next_level_tasks.append(ct)
            if stack[0] == 0: #当前层任务已经全部遍历
                layers.append(tuple(current_level_tasks)) #存储当前层所有任务到layers
                current_level_tasks = [] #清空current_level_tasks
                stack[0] = len(next_level_tasks) #下一层任务进栈
                for i in range(len(next_level_tasks)):
                    stack[i+1] = next_level_tasks[i]
                next_level_tasks = []
        layers = tuple(layers)
        return layers

    def single_chepest_VM_cost(self):  # 使用一个最便宜VM的cost值
        tts = self.total_task_size()
        ls = VM.SPEEDS[VM.SLOWEST]
        uc = VM.UNIT_COSTS[VM.SLOWEST]
        makespan = tts / ls
        hour = math.ceil(makespan / VM.INTERVAL)
        cost = hour * uc
        return cost

    def re_read_workfolow(self):  # 读取工作流(MOACS用)
        # 获取wf名
        # 读取第1行,获得task个数
        list = self.Source[0]
        self.task_num = len(list)

        # 读取第2行,获取task_size
        list = self.Source[1]
        for i in range(self.task_num):
            list[i] = float(list[i])  # str转为float数
        self.task_size = tuple(list)  # 将列表转为元组

        # 读取第3行, 获取边的头结点
        list = self.Source[2]
        for i in range(len(list)):
            list[i] = int(list[i])  # str转为int
        heads = list

        # 读取第4行, 获取边的尾结点
        list = self.Source[3]
        for i in range(len(list)):
            list[i] = int(list[i])  # str转为int
        tails = list

        # 读取第5行, 获取边的权重
        list = self.Source[4]
        for i in range(len(list)):
            list[i] = float(list[i])  # str转为float数
        weights = list  # 将列表转为元组

        # 读取第6行，获取FastSchedule信息
        list = self.Source[5]
        self.fast_schedule_cost = float(list[2])
        self.fast_schedule_makespan = float(list[3])

        # 读取第7行，获取CheapSchedule信息
        list = self.Source[6]
        self.cheap_schedule_cost = float(list[2])
        self.cheap_schedule_makespan = float(list[3])

        # 处理边信息
        ws = [[[] for i in range(self.task_num)] for i in range(self.task_num)]  # 存放边权重
        tt = [[[] for i in range(self.task_num)] for i in range(self.task_num)]  # 存放边传输时间
        is_child = [[False for i in range(self.task_num)] for i in
                    range(self.task_num)]  # is_child[i][j]表示任务j是否为任务i的子任务
        parents = []  # 创建一个空列表,存储每一个任务的全部父任务编号
        children = []  # 创建一个空列表,存储每一个任务的全部子任务编号
        for i in range(self.task_num):  # 创建一个task_num行的列表（行）
            parents.append([])  # 初始化parents[i]为空
            children.append([])  # 初始化children[i]为空
        for i in range(len(heads)):
            h = heads[i]  # 头结点
            t = tails[i]  # 尾结点
            w = weights[i]  # 权值
            # print(h,t,w)
            parents[t].append(h)
            children[h].append(t)
            ws[h][t] = w
            tt[h][t] = w / VM.NETWORK_SPEED
            is_child[h][t] = True
        #   获取入口任务以及出口任务编号
        en_task_num = 0
        ex_task_num = 0
        for i in range(self.task_num):
            if len(parents[i]) == 0:
                self.entry_task = i
                en_task_num = en_task_num + 1
            if len(children[i]) == 0:
                self.exit_task = i
                ex_task_num = ex_task_num + 1
        if en_task_num != 1:  # 检查entry_task_num个数
            print('Workflow ERROR: entry_task_num = ' + en_task_num)
            while True:
                pass
        if ex_task_num != 1:  # 检查exit_task_num个数
            print('Workflow ERROR: exit_task_num = ' + ex_task_num)
            while True:
                pass
        #   去除冗余边(未实现)

        #   获得can_arrive,arrive_tasks
        can_arrive = [[False for i in range(self.task_num)] for i in
                      range(self.task_num)]  # can_arrive[i][j]:任务i是否可达任务j
        arrive_tasks = [[] for i in range(self.task_num)]  # 每个节点可达的tasks
        #       自end_task开始，遍历整个DAG
        remaining_out_edge_num = [0 for i in range(self.task_num)]  # 每个节点剩余出边
        stack = [0 for i in range(self.task_num + 1)]  # 栈,存放剩余出边为0的任务,stack[0]存储栈中任务数
        for i in range(self.task_num):
            remaining_out_edge_num[i] = len(children[i])  # 初始化每个节点剩余出边为子节点个数
        stack[0] = 1
        stack[1] = self.exit_task  # exit_task入栈
        while stack[0] != 0:
            # tid出栈
            tid = stack[stack[0]]
            stack[0] = stack[0] - 1
            for pt in parents[tid]:  # 遍历出栈任务tid的每一个父任务pt
                remaining_out_edge_num[pt] = remaining_out_edge_num[pt] - 1  # 父任务pt出边减一
                if remaining_out_edge_num[pt] == 0:  # 父任务pt无出边则入栈
                    stack[0] = stack[0] + 1
                    stack[stack[0]] = pt
                for ct in arrive_tasks[tid]:  # 遍历出栈任务tid的每一个可达任务ct,将ct可达的任务录入arrive_tasks[pt]
                    if can_arrive[pt][ct] == False:
                        can_arrive[pt][ct] = True
                        arrive_tasks[pt].append(ct)
                if can_arrive[pt][tid] == False:  # 设置pt可达tid
                    can_arrive[pt][tid] = True
                    arrive_tasks[pt].append(tid)
        for i in range(self.task_num):  # arrive_tasks转置,按照深度优先遍历顺序排列
            arrive_tasks[i].reverse()

        #   获得pass_tasks
        pass_tasks = [[] for i in range(self.task_num)]  # 每个节点经过的tasks
        for i in range(self.task_num):
            if can_arrive[self.entry_task][i]:
                pass_tasks[i].append(self.entry_task)
            for j in arrive_tasks[self.entry_task]:
                if can_arrive[j][i]:
                    pass_tasks[i].append(j)

        # 建立最大输入时间
        max_input_time = [0.0 for i in range(self.task_num)]
        for t in range(self.task_num):
            for pt in parents[t]:
                max_input_time[t] = max(max_input_time[t], tt[pt][t])

        # 建立最大输出时间
        max_output_time = [0.0 for i in range(self.task_num)]
        for t in range(self.task_num):
            for ct in children[t]:
                max_output_time[t] = max(max_output_time[t], tt[t][ct])

        # 转换为tuple类型的成员变量
        self.TransDataSize = tuple(tuple(y) for y in ws)
        # self.TransDataSize = tran_list_to_tuple(ws)
        # self.TransDataSize = tuple(ws)  # 将列表转为元组
        self.TransRequireTime = tuple(tuple(y) for y in tt)
        self.is_child = tuple(tuple(y) for y in is_child)
        self.parents = tuple(tuple(y) for y in parents)
        self.children = tuple(tuple(y) for y in children)
        self.can_arrive = tuple(tuple(y) for y in can_arrive)
        self.arrive_tasks = tuple(tuple(y) for y in arrive_tasks)
        self.pass_tasks = tuple(tuple(y) for y in pass_tasks)
        self.max_input_time = tuple(max_input_time)
        self.max_output_time = tuple(max_output_time)
        self.DTL_layers = self.cal_DTL()
        # print("finish reading workflow")