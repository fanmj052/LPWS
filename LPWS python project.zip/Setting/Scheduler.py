from abc import abstractmethod, ABC
import random

class Scheduler(ABC): #ABC:抽象基类
    wf = None  # 求解的工作流
    tiny_num = 1E-8 #极小正数,用于浮点数比较
    def __init__(self):
        pass



    @abstractmethod
    def schedule(self,wf): #抽象方法
        """
        生成调度解
        """